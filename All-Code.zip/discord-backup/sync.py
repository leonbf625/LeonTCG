"""Publish a bounded private dashboard snapshot; never sends Discord credentials."""
import json
import urllib.parse
import urllib.request


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def snapshot(archive):
    report = archive.report()
    # Detailed discovery errors and signed attachment URLs remain on the PC.
    report.pop("events", None)
    report["recent_messages"] = [dict(zip(
        ["id", "channel_id", "author", "timestamp", "content"], row))
        for row in archive.db.execute('''SELECT id,channel_id,author,timestamp,substr(content,1,4000)
            FROM messages ORDER BY length(id) DESC,id DESC LIMIT 200''')]
    report["message_scope"] = "Most recent 200 archived messages; full history and attachments remain on the Windows PC."
    return report


def publish(archive, website, token, opener=None):
    parsed = urllib.parse.urlsplit(website.strip())
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Website must be an HTTPS URL without credentials, query or fragment")
    if not token.strip():
        raise ValueError("A separate dashboard upload token is required")
    body = json.dumps(snapshot(archive), ensure_ascii=False).encode("utf-8")
    if len(body) > 2_000_000:
        raise ValueError("Dashboard snapshot exceeds 2 MB; local backup remains intact")
    request = urllib.request.Request(website.rstrip("/") + "/api/sync", data=body, method="POST", headers={
        "Content-Type": "application/json", "Authorization": "Bearer " + token.strip(),
    })
    open_request = opener or urllib.request.build_opener(NoRedirect()).open
    try:
        with open_request(request, timeout=60) as response:
            result = json.load(response)
            if not result.get("ok"):
                raise RuntimeError("Website did not confirm saving the dashboard snapshot")
        return result
    except Exception as exc:
        if isinstance(exc, RuntimeError):
            raise
        # Do not leak the request headers or website token in diagnostics.
        raise RuntimeError("Dashboard upload failed; check website URL, upload token, and connectivity") from None
