"""Repeatedly scan accessible server channels and optionally sync a private website."""
import argparse
import getpass
import os
import threading

from backup import Archive, DiscordAPI, Stopped, discover, run_backup
from sync import publish


def cycle(api, archive, selected=None, media=True, website="", upload_token="", notify=print):
    account = api.get("/users/@me")
    archive.bind_account(account)
    notify(f"Connected to {account.get('username', 'unknown')} (ID {account['id']})")
    channels = discover(api, archive, notify)
    if selected is not None:
        channels = [channel for channel in channels if channel["id"] in selected]
    failures = run_backup(api, archive, channels, media, notify)
    if not channels:
        notify("No selected/readable candidate channels found; check discovery errors.")
        failures += 1
    if website:
        publish(archive, website, upload_token)
        notify("Private website snapshot saved. Cloudflare may take up to a minute to show updates.")
    return failures


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="DiscordBackup")
    parser.add_argument("--interval-minutes", type=int, default=15)
    parser.add_argument("--bot", action="store_true")
    parser.add_argument("--no-attachments", action="store_true")
    parser.add_argument("--website", default="")
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    if args.interval_minutes < 5:
        parser.error("Use an interval of at least five minutes")
    token = os.environ.get("DISCORD_BACKUP_TOKEN") or getpass.getpass("Discord token (hidden): ")
    upload_token = ""
    if args.website:
        upload_token = os.environ.get("DASHBOARD_UPLOAD_TOKEN") or getpass.getpass("Website upload token (NOT your Discord token): ")
    stop = threading.Event()
    api = DiscordAPI(token, bot=args.bot, stop=stop)
    archive = Archive(args.output)
    try:
        while True:
            try:
                failures = cycle(api, archive, media=not args.no_attachments, website=args.website, upload_token=upload_token)
                print(f"Scan ended with {failures} failed operations.")
                if args.once:
                    return 1 if failures else 0
            except Exception as exc:
                print(f"Scan failed: {exc}")
                if args.once:
                    return 1
            print(f"Next scan in {args.interval_minutes} minutes. Ctrl+C stops.")
            stop.wait(args.interval_minutes * 60)
    except (KeyboardInterrupt, Stopped):
        stop.set()
        return 130
    finally:
        archive.report()
        archive.close()


if __name__ == "__main__":
    raise SystemExit(main())
