import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
import urllib.error

from backup import APIError, Archive, DiscordAPI, Stopped, attachment_url, backup_channel, discover, download_attachments, run_backup


def message(identifier, content=None, attachments=None):
    return {"id": str(identifier), "content": content or f"message {identifier}",
            "author": {"username": "test"}, "timestamp": "2026-01-01T00:00:00Z",
            "attachments": attachments or []}


class FakeAPI:
    def __init__(self, pages):
        self.pages = list(pages)
        self.calls = []
        self.stop = threading.Event()

    def get(self, path, **params):
        self.calls.append((path, params))
        response = self.pages.pop(0)
        if isinstance(response, Exception):
            raise response
        return response


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.archive = Archive(self.temp.name)
        self.channel = {"id": "42", "name": "test", "type": 0}
        self.archive.channel(self.channel)

    def tearDown(self):
        self.archive.close()
        self.temp.cleanup()

    def test_resume_after_failure_and_incremental_update(self):
        first = [message(n) for n in range(200, 100, -1)]
        api = FakeAPI([first, APIError(503, "test failure")])
        with self.assertRaises(APIError):
            backup_channel(api, self.archive, "42")
        self.assertEqual(self.archive.state("42"), ("0", 1, "101", "200"))
        self.archive.close()
        self.archive = Archive(self.temp.name)
        api = FakeAPI([[message(100), message(99)]])
        backup_channel(api, self.archive, "42")
        self.assertEqual(api.calls[0][1]["before"], "101")
        self.assertEqual(self.archive.state("42"), ("200", 0, None, None))
        api = FakeAPI([[message(202), message(201), message(200)]])
        backup_channel(api, self.archive, "42")
        self.assertIsNone(api.calls[0][1]["before"])
        self.assertEqual(self.archive.state("42")[0], "202")
        self.assertEqual(self.archive.db.execute("SELECT COUNT(*) FROM messages").fetchone()[0], 104)
        self.archive.export("42")
        lines = (Path(self.temp.name) / "exports/42.jsonl").read_text().splitlines()
        self.assertEqual(json.loads(lines[0])["id"], "99")
        self.assertEqual(json.loads(lines[-1])["id"], "202")

    def test_empty_channel_finishes_without_fabricated_messages(self):
        backup_channel(FakeAPI([[]]), self.archive, "42")
        report = self.archive.report()["channels"][0]
        self.assertEqual(report["messages"], 0)
        self.assertEqual(report["status"], "history backed up")

    def test_channel_failure_does_not_prevent_next_channel(self):
        api = FakeAPI([APIError(403, "test permission"), [message(1)]])
        channels = [self.channel, {"id": "43", "name": "second"}]
        self.assertEqual(run_backup(api, self.archive, channels, False, lambda _: None), 1)
        report = {row["id"]: row for row in self.archive.report()["channels"]}
        self.assertEqual(report["42"]["status"], "failed")
        self.assertEqual(report["43"]["messages"], 1)

    def test_stop_retains_committed_checkpoint(self):
        api = FakeAPI([[message(n) for n in range(200, 100, -1)], Stopped()])
        with self.assertRaises(Stopped):
            backup_channel(api, self.archive, "42")
        self.assertEqual(self.archive.state("42")[2], "101")
        self.assertEqual(self.archive.report()["channels"][0]["status"], "paused")

    def test_repeated_page_is_error_and_does_not_advance(self):
        page = [message(n) for n in range(200, 100, -1)]
        with self.assertRaisesRegex(ValueError, "did not advance"):
            backup_channel(FakeAPI([page, page]), self.archive, "42")
        self.assertEqual(self.archive.state("42")[2], "101")

    def test_attachment_rejection_is_reported(self):
        self.archive.state("42")
        self.archive.page("42", [message(1, attachments=[{
            "id": "2", "filename": "../../bad.exe", "url": "https://example.com/file"}])], "1", "1")
        failures = download_attachments(self.archive, threading.Event())
        self.assertEqual(failures, 1)
        self.assertEqual(self.archive.report()["channels"][0]["attachment_errors"], 1)

    def test_discovery_records_permission_failure_and_keeps_other_guild(self):
        api = FakeAPI([
            [{"id": "1", "name": "blocked"}, {"id": "2", "name": "open"}],
            APIError(403, "test"),
            [{"id": "12", "name": "voice", "type": 2}],
            {"threads": [{"id": "13", "name": "thread", "type": 11}]},
        ])
        result = discover(api, self.archive)
        self.assertEqual({item["id"] for item in result}, {"12", "13"})
        self.assertIn("403", self.archive.report()["events"][0]["detail"])

    def test_sql_content_and_unicode_round_trip(self):
        text = "Pikachu ⚡ '; DROP TABLE messages; --"
        backup_channel(FakeAPI([[message(1, text)]]), self.archive, "42")
        self.assertEqual(self.archive.db.execute("SELECT content FROM messages").fetchone()[0], text)


class Response(io.BytesIO):
    def __init__(self, value, headers=None):
        super().__init__(json.dumps(value).encode())
        self.headers = headers or {}


class APITests(unittest.TestCase):
    def test_token_only_sent_to_discord_api(self):
        seen = []
        def opener(request, timeout):
            seen.append(request)
            return Response({"id": "1"})
        api = DiscordAPI("secret", opener=opener)
        self.assertEqual(api.get("/users/@me"), {"id": "1"})
        self.assertEqual(seen[0].get_header("Authorization"), "secret")
        self.assertEqual(seen[0].full_url, "https://discord.com/api/v10/users/@me")
        with self.assertRaises(ValueError):
            api.get("https://example.com")

    def test_rate_limit_then_success(self):
        results = [urllib.error.HTTPError("https://discord.com", 429, "limited", {}, io.BytesIO(b'{"retry_after": 1}')), Response([])]
        def opener(request, timeout):
            result = results.pop(0)
            if isinstance(result, Exception):
                raise result
            return result
        api = DiscordAPI("secret", opener=opener)
        pauses = []
        api.pause = pauses.append
        self.assertEqual(api.get("/users/@me/guilds"), [])
        self.assertEqual(pauses, [1])

    def test_auth_failure_is_not_retried_or_leaked(self):
        def opener(request, timeout):
            raise urllib.error.HTTPError("https://discord.com", 401, "secret", {}, io.BytesIO(b"secret"))
        with self.assertRaises(APIError) as context:
            DiscordAPI("secret", opener=opener).get("/users/@me")
        self.assertNotIn("secret", str(context.exception))
        self.assertEqual(context.exception.status, 401)

    def test_attachment_hosts_are_restricted(self):
        for url in ["http://cdn.discordapp.com/file", "https://evil.com", "https://cdn.discordapp.com.evil.com/a", "file:///etc/passwd", "https://user@cdn.discordapp.com/a"]:
            with self.assertRaises(ValueError):
                attachment_url(url)
        self.assertEqual(attachment_url("https://cdn.discordapp.com/attachments/a"), "https://cdn.discordapp.com/attachments/a")


if __name__ == "__main__":
    unittest.main()
