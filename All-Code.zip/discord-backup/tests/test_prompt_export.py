from pathlib import Path
import tempfile
import unittest

from backup import Archive, backup_channel
from prompt_export import create_prompt, redact
from test_backup import FakeAPI, message


class PromptTests(unittest.TestCase):
    def test_redacts_known_credentials_and_common_patterns(self):
        token = 'A' * 24 + '.' + 'B' * 6 + '.' + 'C' * 27
        text = f'email=test@example.com\nAuthorization: Bearer private\n{token}\npassword="hidden"\nmy-exact-upload-key'
        result = redact(text, ['my-exact-upload-key'])
        for secret in ('test@example.com', 'private', token, 'hidden', 'my-exact-upload-key'):
            self.assertNotIn(secret, result)

    def test_exports_coverage_and_optional_scoped_messages(self):
        with tempfile.TemporaryDirectory() as folder:
            archive = Archive(folder)
            try:
                archive.bind_account({'id': '1', 'username': 'TEST ACCOUNT'})
                for cid in ('42', '43'):
                    archive.channel({'id': cid, 'name': 'TEST CHANNEL ' + cid})
                    backup_channel(FakeAPI([[message(100 if cid == '42' else 101, f'TEST MESSAGE {cid}')]]), archive, cid)
                archive.report()
                path, text = create_prompt(folder, ['TEST LOG with exact-secret'], credentials=['exact-secret'])
                self.assertTrue(path.exists())
                self.assertIn('TEST LOG with [REDACTED CREDENTIAL]', text)
                self.assertNotIn('TEST MESSAGE 42', text)
                path, text = create_prompt(folder, include_messages=True, selected=['42'])
                self.assertIn('TEST MESSAGE 42', text)
                self.assertNotIn('TEST MESSAGE 43', text)
                self.assertIn('untrusted', text)
                self.assertIn('No AI service was contacted', text)
            finally:
                archive.close()

    def test_requires_an_existing_backup(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaisesRegex(ValueError, 'No backup report'):
                create_prompt(folder)


if __name__ == '__main__':
    unittest.main()
