import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from unittest.mock import patch

from backup import Archive, DiscordAPI, backup_channel, download_attachments
from monitor import cycle
from sync import publish, snapshot
from web_app import State, make_handler
from test_backup import FakeAPI, message


class WorkflowTests(unittest.TestCase):
    def test_account_binding_prevents_mixing_accounts(self):
        with tempfile.TemporaryDirectory() as folder:
            archive = Archive(folder)
            try:
                archive.bind_account({"id": "1", "username": "first", "token": "NEVER STORE"})
                self.assertEqual(archive.report()["account"]["username"], "first")
                with self.assertRaisesRegex(ValueError, "different Discord account"):
                    archive.bind_account({"id": "2", "username": "second"})
                self.assertNotIn("NEVER STORE", (Path(folder) / "report.json").read_text())
            finally:
                archive.close()

    def test_coverage_tracks_checked_unchecked_failed_and_times(self):
        with tempfile.TemporaryDirectory() as folder:
            archive = Archive(folder)
            try:
                for cid in ("1", "2", "3"):
                    archive.channel({"id": cid, "name": "channel " + cid})
                self.assertEqual(archive.report()["coverage"]["unchecked"], 3)
                backup_channel(FakeAPI([[message(50)]]), archive, "1")
                archive.status("2", "failed", "HTTP 403")
                report = archive.report()
                self.assertEqual(report["coverage"], {"discovered": 3, "checked": 2, "unchecked": 1, "history_complete": 1, "failed": 1})
                rows = {row["id"]: row for row in report["channels"]}
                self.assertIsNotNone(rows["1"]["last_started_at"])
                self.assertIsNotNone(rows["1"]["last_success_at"])
                self.assertIsNotNone(rows["2"]["last_checked_at"])
                self.assertIsNone(rows["2"]["last_success_at"])
                self.assertIsNone(rows["3"]["last_checked_at"])
                self.assertTrue((Path(folder) / "coverage.csv").is_file())
            finally:
                archive.close()

    def test_snapshot_bounded_and_contains_no_attachment_urls_or_credentials(self):
        with tempfile.TemporaryDirectory() as folder:
            archive = Archive(folder)
            try:
                archive.bind_account({"id": "1", "username": "test"})
                archive.channel({"id": "42", "name": "test"})
                archive.state("42")
                archive.page("42", [message(n) for n in range(1, 251)], "1", "250")
                archive.event("scope", "sensitive local error")
                value = snapshot(archive)
                self.assertEqual(len(value["recent_messages"]), 200)
                self.assertEqual(value["recent_messages"][0]["id"], "250")
                self.assertNotIn("events", value)
                requests = []
                def opener(request, timeout):
                    requests.append(request)
                    return io.BytesIO(b'{"ok": true}')
                publish(archive, "https://example.workers.dev", "website-secret", opener)
                self.assertEqual(requests[0].get_header("Authorization"), "Bearer website-secret")
                self.assertNotIn("website-secret", requests[0].data.decode())
                self.assertNotIn("sensitive local error", requests[0].data.decode())
                with self.assertRaises(ValueError):
                    publish(archive, "http://example.com", "secret", opener)
            finally:
                archive.close()

    def test_attachment_download_has_no_auth_and_is_atomic(self):
        with tempfile.TemporaryDirectory() as folder:
            archive = Archive(folder)
            try:
                archive.channel({"id": "42", "name": "test"})
                archive.state("42")
                archive.page("42", [message(1, attachments=[{"id": "2", "filename": "../sample.txt", "url": "https://cdn.discordapp.com/attachments/example"}])], "1", "1")
                class Response(io.BytesIO):
                    headers = {"Content-Length": "5"}
                class Opener:
                    def open(self, url, timeout):
                        assert isinstance(url, str), "Account request/headers unexpectedly reused"
                        return Response(b"hello")
                with patch("backup.urllib.request.build_opener", return_value=Opener()):
                    self.assertEqual(download_attachments(archive, threading.Event()), 0)
                relative, error = archive.db.execute("SELECT saved_path,error FROM attachments").fetchone()
                self.assertIsNone(error)
                self.assertEqual((Path(folder) / relative).read_bytes(), b"hello")
                self.assertFalse(list(Path(folder).rglob("*.part")))
            finally:
                archive.close()

    def test_monitor_cycle_discovers_new_channel_and_backs_it_up(self):
        with tempfile.TemporaryDirectory() as folder:
            archive = Archive(folder)
            try:
                api = FakeAPI([
                    {"id": "1", "username": "test-account"},
                    [{"id": "10", "name": "TEST SERVER"}],
                    [{"id": "42", "name": "TEST channel", "type": 2}],
                    {"threads": []}, [message(1)],
                ])
                self.assertEqual(cycle(api, archive, media=False, notify=lambda _: None), 0)
                report = archive.report()
                self.assertEqual(report["account"]["username"], "test-account")
                self.assertEqual(report["coverage"]["history_complete"], 1)
            finally:
                archive.close()


class LocalServerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.state = State(self.temp.name)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.state))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}"
        # No inherited egress proxy is needed for a local test server.
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)
        self.temp.cleanup()

    def request(self, path, data=None, key=True, origin=None):
        headers = {"X-Local-Key": self.state.key} if key else {}
        if origin:
            headers["Origin"] = origin
        if data is not None:
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(self.base + path, data=json.dumps(data).encode() if data is not None else None, headers=headers)
        return self.opener.open(request, timeout=5)

    def test_actual_http_shell_api_and_session_protection(self):
        with self.request("/", key=False) as response:
            self.assertIn(b"Channel coverage", response.read())
        with self.assertRaises(urllib.error.HTTPError) as denied:
            self.request("/api/report", key=False)
        self.assertEqual(denied.exception.code, 401)
        with self.request("/api/mode") as response:
            self.assertTrue(json.load(response)["local"])
        with self.request("/api/report") as response:
            self.assertEqual(json.load(response)["channels"], [])
        with self.assertRaises(urllib.error.HTTPError) as denied:
            self.request("/api/stop", {}, origin="https://untrusted.example")
        self.assertEqual(denied.exception.code, 401)

    def test_state_never_returns_secrets(self):
        self.state.config = {"token": "discord-secret", "upload_token": "website-secret"}
        with self.request("/api/state") as response:
            text = response.read().decode()
            self.assertNotIn("discord-secret", text)
            self.assertNotIn("website-secret", text)
            self.assertTrue(json.loads(text)["credential_held"])

    def test_http_prompt_export_redacts_credentials_and_preserves_log_context(self):
        archive = Archive(self.temp.name)
        try:
            archive.bind_account({"id": "1", "username": "TEST ACCOUNT"})
            archive.channel({"id": "42", "name": "TEST CHANNEL"})
            archive.report()
        finally:
            archive.close()
        self.state.config = {"token": "do-not-export-this-token"}
        self.state.log("TEST diagnostic containing do-not-export-this-token")
        with self.request("/api/export-prompt", {"include_messages": False, "selected": []}) as response:
            text = response.read().decode()
            self.assertIn("TEST diagnostic containing [REDACTED CREDENTIAL]", text)
            self.assertNotIn("do-not-export-this-token", text)
            self.assertIn("TEST CHANNEL", text)
        self.assertEqual(len(list((Path(self.temp.name) / "prompts").glob("*.md"))), 1)


if __name__ == "__main__":
    unittest.main()
