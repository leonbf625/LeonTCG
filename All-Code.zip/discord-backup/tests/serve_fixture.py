"""Clearly labeled synthetic data, served only for the browser smoke test."""
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backup import Archive, backup_channel
from test_backup import FakeAPI, message
from web_app import State, make_handler

with tempfile.TemporaryDirectory() as folder:
    archive = Archive(folder)
    archive.bind_account({"id": "123", "username": "TEST ACCOUNT — SYNTHETIC DATA"})
    for identifier, name in [("42", "checked TEST channel"), ("43", "unchecked TEST channel"), ("44", "failed TEST channel")]:
        archive.channel({"id": identifier, "name": name, "guild_id": "1", "guild_name": "SYNTHETIC TEST SERVER"})
    backup_channel(FakeAPI([[message(100, '<script>globalThis.UNSAFE_EXECUTED=true</script> TEST MESSAGE')]]), archive, "42")
    archive.status("44", "failed", "TEST permission denial: HTTP 403")
    state = State(folder)
    state.save_report(archive)
    archive.close()
    state.log("SYNTHETIC TEST RUN: 2 channels checked; 1 channel unchecked; 1 permission failure.")
    server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(state))
    print(json.dumps({"url": f"http://127.0.0.1:{server.server_port}/#key={state.key}"}), flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()
