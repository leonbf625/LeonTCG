import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
import urllib.error

from upload_exports import Progress, check_receiver, partitions, upload, upload_file


def fixture(count=3):
    return {'guild':{'id':'1','name':'TEST SERVER'},'channel':{'id':'42','name':'TEST CHANNEL'},
            'exportedAt':'2026-11-02T00:00:00Z','messageCount':count,
            'messages':[{'id':str(100+n),'timestamp':'2026-11-01T00:00:00Z','content':'TEST '+'⚡'*2000,'author':{'name':'TEST USER'}} for n in range(count)]}


class ExportUploadTests(unittest.TestCase):
    def test_readiness_check_does_not_send_export_data(self):
        seen=[]
        def opener(request,timeout):
            seen.append(request)
            return io.BytesIO(b'{"ready":true,"format":"DiscordChatExporter","version":1}')
        check_receiver('https://example.com','upload-token',opener)
        self.assertEqual(seen[0].full_url,'https://example.com/api/upload-status')
        self.assertIsNone(seen[0].data)
        with self.assertRaisesRegex(RuntimeError,'No export data'):
            check_receiver('https://example.com','token',lambda request,timeout:io.BytesIO(b'{}'))

    def test_partitioning_keeps_all_messages_and_byte_limit(self):
        raw=json.dumps(fixture(),ensure_ascii=False).encode()
        parts=list(partitions(raw,max_bytes=8000))
        self.assertEqual(len(parts),3)
        records=[]
        for n,body in enumerate(parts,start=1):
            self.assertLessEqual(len(body),8000)
            value=json.loads(body)
            self.assertEqual(value['messageCount'],len(value['messages']))
            self.assertEqual(value['_upload']['part'],n)
            self.assertEqual(value['_upload']['parts'],3)
            records.extend(value['messages'])
        self.assertEqual(records,fixture()['messages'])

    def test_invalid_source_not_uploaded_or_truncated(self):
        for raw in [b'not JSON',b'{"guild":{}}',json.dumps({**fixture(),'messageCount':99}).encode()]:
            with self.assertRaises(ValueError):list(partitions(raw))
        with self.assertRaisesRegex(ValueError,'not truncated'):
            list(partitions(json.dumps(fixture()).encode(),max_bytes=500))

    def test_request_contains_separate_upload_token_and_verified_checksum(self):
        body=list(partitions(json.dumps(fixture(0)).encode()))[0]
        seen=[]
        def opener(request,timeout):
            seen.append(request)
            return io.BytesIO(json.dumps({'success':True,'key':'export:test','sha256':hashlib.sha256(request.data).hexdigest()}).encode())
        result=upload(body,'https://example.workers.dev','website-token',opener=opener)
        self.assertTrue(result['success'])
        self.assertEqual(seen[0].get_header('Authorization'),'Bearer website-token')
        self.assertNotIn(b'website-token',seen[0].data)
        with self.assertRaises(ValueError):upload(body,'http://example.com','token',opener=opener)

    def test_progress_skips_confirmed_parts_and_never_saves_token(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'test.json';path.write_text(json.dumps(fixture()))
            progress=Progress(Path(folder)/'progress.json');calls=[]
            def send(body,endpoint,token):
                calls.append(body)
                return {'success':True,'key':'export:42:test','sha256':hashlib.sha256(body).hexdigest(),'messages':3}
            self.assertEqual(upload_file(path,'https://example.com','SECRET',progress,lambda _:None,send),1)
            progress=Progress(progress.path)
            self.assertEqual(upload_file(path,'https://example.com','SECRET',progress,lambda _:None,send),0)
            self.assertEqual(len(calls),1)
            self.assertNotIn('SECRET',progress.path.read_text())

    def test_missing_receiver_checksum_does_not_confirm_progress(self):
        body=list(partitions(json.dumps(fixture(0)).encode()))[0]
        with self.assertRaisesRegex(RuntimeError,'checksum'):
            upload(body,'https://example.com','token',opener=lambda request,timeout:io.BytesIO(b'{"success":true,"key":"old"}'))

    def test_rate_limit_retries_without_losing_body(self):
        body=list(partitions(json.dumps(fixture(0)).encode()))[0]
        attempts=[];delays=[]
        def opener(request,timeout):
            attempts.append(request.data)
            if len(attempts)==1:raise urllib.error.HTTPError('https://example.com',429,'limited',{'Retry-After':'1'},None)
            return io.BytesIO(json.dumps({'success':True,'key':'export:test','sha256':hashlib.sha256(body).hexdigest()}).encode())
        upload(body,'https://example.com','token',opener=opener,pause=delays.append)
        self.assertEqual(attempts,[body,body]);self.assertEqual(delays,[1])


if __name__=='__main__':unittest.main()
