@echo off
setlocal
cd /d "%~dp0"
py -3 --version >nul 2>&1
if errorlevel 1 (
  echo Python 3.11 or newer is required. Install Python from https://www.python.org/downloads/windows/
  echo Then run this launcher again.
  pause
  exit /b 1
)
py -3 web_app.py
if errorlevel 1 (
  echo.
  echo The app stopped with an error. Keep this window open to read the error above.
  pause
  exit /b 1
)
