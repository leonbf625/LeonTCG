# Validation results — 2026-11-02

This is a Windows x64 test build. Tests below ran on the Linux build machine.
Synthetic Discord data is labeled TEST/SYNTHETIC and is not included as live
backup data. No Discord account was authenticated and no real messages were read.

| Check | Result | Evidence / scope |
| --- | --- | --- |
| Python unit and local HTTP tests | 30 passed | `artifacts/python-tests.log`; interrupted-page recovery, incremental scans, per-channel failure isolation, account binding, coverage/timestamps, attachment writes, local session security, DeepSeek export/redaction, JSON-file partitioning, readiness checks, resumable upload receipts |
| Cloudflare Worker tests | 15 passed | Fail-closed configuration, private assets/reports, invalid auth/payloads, bounded uploads, storage, legacy export compatibility, idempotency/concurrent uploads, pagination, and Python-to-Worker loopback HTTP uploads/checksum/resume with an in-memory KV substitute |
| Launcher tests | 2 passed | ZIP extraction and path-traversal rejection, tested with the Linux build of the Go source |
| Real Chromium interface smoke | Passed | Account display, checked/unchecked/failed counts and filters, row selection, errors/logs, escaped message text, DeepSeek Markdown response, and authenticated cloud-style JSON file upload/list display; two synthetic local-server browser flows |
| Cloudflare deployment dry run | Passed | Wrangler bundled the Worker and static assets and recognized existing-receiver EXPORTS/asset/email bindings; no deployment or authenticated Cloudflare operation occurred |
| Windows executable build | Passed | Cross-compiled PE32+ Windows 10 x86-64 console executable; official Python runtime bundled; checksum in `artifacts/SHA256SUMS.txt` |
| Upstream artifact integrity | Verified | Go archive checked against official SHA-256 metadata; Python NuGet package checked against official SHA-512 catalog metadata; TLS verification remained enabled |

## Not verified

- Launching the EXE on Windows or the target computer's antivirus/SmartScreen behavior.
- Signing in to a real Discord account, reading live public/private channels,
  channel/thread visibility, Discord's treatment of personal-account automation,
  or live attachment downloads.
- Cloudflare account login, namespace creation, actual deployment, free-tier usage,
  deployed KV persistence, or live website synchronization.
- Long-term scheduled operation, PC sleep/resume, very large archives, or recovery
  from a real Windows power loss/full disk. Tests cover simulated interruptions.

These limits are not recorded as passing tests. A public server/channel does not
provide anonymous access to its message-history API. Live testing needs a local
credential and channels the user is authorized to access.

## Next Windows test

1. Run the EXE. Confirm the local interface opens and no Python installation is requested.
2. Enter a credential locally, find channels, and verify the displayed Discord account ID.
3. Select one authorized test channel, disable automatic scans initially, and back it up.
4. Check saved messages and `report.json` / `coverage.csv`; stop mid-backup and resume
   using the same folder to verify recovery on the actual computer.
5. Export the DeepSeek prompt, review redaction, and confirm no token appears.
6. Enable automatic scans after the single-channel check succeeds. Deploy and connect
   the private website only after its separate authentication is configured.

## DiscordChatExporter integration

The uploaded `DiscordChatExporter-2.48.zip` contains 292 source entries and no
Windows executable. Its JsonMessageWriter.cs was inspected to align the JSON
schema (guild, channel, exportedAt, messages, messageCount, and author.name).
The source archive was not executed or redistributed.

The updated Worker and Windows folder uploader have passed local simulated/HTTP
checks. The existing live Worker URL was not fetched or changed: its hostname
was absent from the running environment allowlist. The required hostname was
saved to the configuration draft; saving does not apply it to the running task.
The Cloudflare account still needs the prepared code deployed with its existing
EXPORTS binding and separate dashboard/upload secrets.
