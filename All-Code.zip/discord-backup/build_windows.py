"""Assemble the Windows EXE using an official runtime and Go compiler.

Inputs: launcher/runtime.zip made from a checksum-verified official Python
NuGet package; GO_BIN pointing to a checksum-verified Go compiler.
"""
import hashlib
import os
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
FILES = ['backup.py', 'monitor.py', 'sync.py', 'web_app.py', 'prompt_export.py', 'upload_exports.py', 'README.md', 'THIRD_PARTY_NOTICES.txt', 'runtime-provenance.json']


def main():
    launcher = ROOT / 'launcher'
    runtime = launcher / 'runtime.zip'
    if not runtime.is_file():
        raise SystemExit('Create launcher/runtime.zip from a checksum-verified official Python Windows package first.')
    with zipfile.ZipFile(launcher / 'app.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name in FILES:
            output.write(ROOT / name, name)
        for path in sorted((ROOT / 'website/public').glob('*')):
            output.write(path, path.relative_to(ROOT))
    artifacts = ROOT / 'artifacts'
    artifacts.mkdir(exist_ok=True)
    exe = artifacts / 'DiscordLocalBackup-Windows-x64.exe'
    env = dict(os.environ, GOOS='windows', GOARCH='amd64', CGO_ENABLED='0', GOTOOLCHAIN='local')
    subprocess.run([os.environ.get('GO_BIN', 'go'), 'build', '-trimpath', '-buildvcs=false', '-ldflags=-s -w -buildid=', '-o', str(exe), '.'], cwd=launcher, env=env, check=True)
    digest = hashlib.sha256(exe.read_bytes()).hexdigest()
    (artifacts / 'SHA256SUMS.txt').write_text(f'{digest}  {exe.name}\n', encoding='ascii')
    with zipfile.ZipFile(artifacts / 'DiscordLocalBackup-Windows-x64.zip', 'w', zipfile.ZIP_DEFLATED) as output:
        for path in (exe, ROOT / 'Upload Exports.cmd', ROOT / 'README.md', ROOT / 'TEST_RESULTS.md', ROOT / 'THIRD_PARTY_NOTICES.txt', ROOT / 'runtime-provenance.json', artifacts / 'SHA256SUMS.txt'):
            if path.exists():
                output.write(path, path.name)
        for path in sorted((ROOT / 'website').rglob('*')):
            relative = path.relative_to(ROOT)
            if path.is_file() and not any(part in {'node_modules', '.wrangler'} for part in relative.parts) and not path.name.startswith('.dev.vars'):
                output.write(path, relative)
    print(f'Windows x64 EXE: {exe.stat().st_size:,} bytes; SHA-256 {digest}')


if __name__ == '__main__':
    main()
