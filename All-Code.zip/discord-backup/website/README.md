# Private Cloudflare dashboard

This is a Cloudflare Worker with static assets and one KV snapshot. It is designed
for the Workers/KV free tiers for personal use. Check current Cloudflare limits
before enabling it; no paid plan or custom domain is needed by this design.
This directory contains deployment files, not proof of a deployed website.

The receiver also accepts DiscordChatExporter JSON with an **EXPORTS** binding.
See [EXISTING_WORKER.md](EXISTING_WORKER.md) to upgrade the supplied POST-only
Worker, preserve existing data, use the Windows folder uploader, and deploy the
single-file version with its embedded private website.

## Windows deployment

Install Node.js LTS, open PowerShell here, and run:

```powershell
.\deploy.ps1
```

The script uses Cloudflare's official browser login on your computer, displays the
connected Cloudflare account, creates a KV namespace, and deploys the dashboard.
It then prompts securely for **two new secrets**, separate from your Discord and
Cloudflare account passwords:

- `DASHBOARD_PASSWORD`: at least 16 characters; used with the dashboard email.
- `UPLOAD_TOKEN`: at least 32 random characters; used only by the local uploader.

Keep these in a password manager. Do not send them in chat. The default dashboard
login name is `you@example.com`, configured in `wrangler.jsonc`.
This is a dashboard username, not Google/Discord OAuth or access to that mailbox.
You may change it before deployment. If multiple Cloudflare accounts are available,
select the intended account when Wrangler prompts or configure `account_id`.

The placeholder namespace ID must be replaced by the actual ID created under
your account. The script attempts the documented `--update-config` flow and stops
if the placeholder remains. Do not rerun namespace creation blindly if it already
succeeded; inspect `wrangler kv namespace list` and set the existing ID instead.

The dashboard returns HTTP 503 until storage and both secrets are configured.
Read access to all assets and API reports requires the dashboard login. Uploads
require a separate Bearer token; the upload token does not grant read access.

## Connect the Windows app

In the app, expand **Automatically update a private Cloudflare website**. Enter
the HTTPS `workers.dev` URL and the separate upload token, then start a backup.
Successful scans publish channel coverage and up to 200 recent message texts.
The Discord token, raw message payloads, signed attachment URLs, full history,
and downloaded attachment files stay on the PC. Message texts and channel names
are private communications: keep dashboard access restricted.

Cloudflare KV is eventually consistent; updates may take around a minute to
appear. The app retries future uploads on its next scan. The dashboard auto-refreshes
every minute. Use an interval of 15 minutes or longer for typical personal use.
The scanner runs on the Windows computer, so that computer must remain awake
and the EXE must stay open. Hosting this dashboard does not create a cloud scanner.

## Verify deployment

1. Open the dashboard in a private browser window. It must request a login.
2. Log in with the dashboard username and its new password. Initially it has zero
   channels and makes no claims of completed scans.
3. Configure the local uploader and back up a channel you are authorized to read.
4. Confirm that the dashboard account ID matches the account shown in the app,
   that channel IDs match, and that checked/unchecked statuses and UTC timestamps
   agree with `report.json` / `coverage.csv`. Browser times display in local time.
5. Confirm a request without authentication cannot read `/api/report`.

Development checks:

```sh
npm ci --ignore-scripts
npm test
npm exec wrangler deploy -- --dry-run
```

Secrets must never be added to `wrangler.jsonc`. Local `.dev.vars` files, if used
for development, are ignored. The uploaded snapshot replaces the previous one;
Cloudflare is a dashboard copy, not the primary durable archive.
