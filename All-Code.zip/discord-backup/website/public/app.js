"use strict";
const $ = id => document.getElementById(id);
let local = false, report = {channels: [], recent_messages: []}, busy = false;
const selected = new Set();
const fragment = new URLSearchParams(location.hash.slice(1));
if (fragment.has("key")) {
  sessionStorage.setItem("backup-local-key", fragment.get("key"));
  history.replaceState(null, "", location.pathname);
}
const localKey = sessionStorage.getItem("backup-local-key") || "";
let credentialHeld = false;
let exportCursor = null, exportRows = [];

async function loadExports(reset = true) {
  if (local) return;
  const value = await api('/api/exports' + (!reset && exportCursor ? '?cursor=' + encodeURIComponent(exportCursor) : ''));
  exportRows = reset ? value.exports : [...exportRows, ...value.exports];
  exportCursor = value.cursor;
  const table = $('saved-exports'); table.replaceChildren();
  for (const entry of exportRows) {
    const row = element('tr'), label = element('td', entry.channel || 'Unknown channel');
    label.append(element('small', entry.guild || 'Unknown server'));
    row.append(label, element('td', entry.messageCount ?? 'Unknown'), element('td', entry.exportedAt ? date(entry.exportedAt) : 'Unknown'), element('td', entry.receivedAt ? date(entry.receivedAt) : 'Unknown'));
    const cell = element('td'), link = element('a', 'Download JSON');
    link.href = '/api/exports/' + encodeURIComponent(entry.key); cell.append(link); row.append(cell); table.append(row);
  }
  $('more-exports').hidden = !exportCursor;
  $('export-note').textContent = `${exportRows.length} exports loaded. ${value.note || ''}`;
}

async function api(path, value) {
  const options = {headers: {"X-Local-Key": localKey}, credentials: "same-origin", cache: "no-store"};
  if (value !== undefined) {
    options.method = "POST";
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(value);
  }
  const response = await fetch(path, options);
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `Request failed (${response.status})`);
  return body;
}

function fail(error) { $("error").textContent = error.message || String(error); $("error").hidden = false; }
function date(value) { return value ? new Date(value).toLocaleString() : "Never"; }
function element(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  return node;
}
function visibleChannels() {
  const search = $("filter-text").value.toLowerCase(), filter = $("filter-status").value;
  return (report.channels || []).filter(channel => {
    const checked = Boolean(channel.last_checked_at);
    return `${channel.guild || ""} ${channel.channel} ${channel.id}`.toLowerCase().includes(search) &&
      (filter !== "Unchecked" || !checked) && (filter !== "Checked" || checked) &&
      (filter !== "Failed" || channel.status === "failed") &&
      (filter !== "History backed up" || channel.status === "history backed up");
  });
}
function renderChannels() {
  const target = $("channels"); target.replaceChildren();
  const visible = visibleChannels();
  $("empty").hidden = visible.length > 0;
  for (const channel of visible) {
    const row = element("tr");
    if (local) {
      const cell = element("td"), checkbox = element("input");
      checkbox.type = "checkbox"; checkbox.checked = selected.has(channel.id);
      checkbox.setAttribute("aria-label", `Select ${channel.channel}`);
      checkbox.addEventListener("change", () => checkbox.checked ? selected.add(channel.id) : selected.delete(channel.id));
      cell.append(checkbox); row.append(cell);
    }
    const label = element("td", channel.channel);
    label.append(element("small", `${channel.guild || "Unknown server"} · ${channel.id}`));
    row.append(label, element("td", channel.last_checked_at ? "Yes" : "No"));
    const result = element("td"), status = channel.status || "not started";
    const style = status === "history backed up" ? "success" : status === "failed" ? "failed" : "pending";
    result.append(element("span", status, `badge ${style}`));
    if (channel.error) result.append(element("small", channel.error));
    if (channel.attachment_errors) result.append(element("small", `${channel.attachment_errors} attachment errors`));
    row.append(result, element("td", date(channel.last_checked_at)), element("td", Number(channel.messages || 0).toLocaleString()));
    target.append(row);
  }
}
function renderMessages() {
  const target = $("messages"); target.replaceChildren();
  const search = $("message-search").value.toLowerCase();
  const channels = new Map((report.channels || []).map(channel => [channel.id, channel]));
  const messages = (report.recent_messages || []).filter(message => message.content.toLowerCase().includes(search));
  for (const message of messages) {
    const channel = channels.get(message.channel_id);
    const article = element("article", undefined, "message");
    const meta = element("div");
    meta.append(element("strong", message.author), element("span", `${channel?.guild || ""} / ${channel?.channel || message.channel_id}`, "muted"));
    article.append(meta, element("small", date(message.timestamp)), element("p", message.content || "[No text content]"));
    target.append(article);
  }
  if (!messages.length) target.append(element("p", "No recent messages match.", "empty"));
}
function render() {
  const channels = report.channels || [];
  $("total").textContent = channels.length;
  $("checked").textContent = channels.filter(channel => channel.last_checked_at).length;
  $("unchecked").textContent = channels.filter(channel => !channel.last_checked_at).length;
  $("failed").textContent = channels.filter(channel => channel.status === "failed").length;
  $("account").textContent = report.account?.username || "Not connected";
  $("account-id").textContent = report.account ? `Account ID: ${report.account.id}` : "Connect locally to verify the account ID.";
  $("freshness").textContent = report.created_at ? `Report updated ${date(report.created_at)} · Times shown in your browser’s time zone.` : "No scan data yet. Nothing has been claimed as checked.";
  $("updated").textContent = report.uploaded_at ? `Website synced ${date(report.uploaded_at)}` : "Archive stays on your computer";
  renderChannels(); renderMessages();
}
async function refresh() {
  report = await api("/api/report"); render();
  if (local) {
    const state = await api("/api/state");
    busy = state.busy; credentialHeld = state.credential_held;
    $("scanner-status").textContent = state.status + (state.next_scan ? ` · Next scan ${date(state.next_scan)}` : "");
    $("logs").textContent = (state.logs || []).join("\n") || "No operations yet.";
    $("discover").disabled = busy; $("start").disabled = busy;
  } else await loadExports();
}
function settings() {
  const token = $("discord-token").value;
  if (!token && !credentialHeld) throw new Error("Enter the Discord token locally to connect.");
  if (!$("folder").value.trim()) throw new Error("Choose a backup folder.");
  return {token, bot: $("bot").checked, folder: $("folder").value,
    attachments: $("attachments").checked, auto: $("auto").checked,
    interval: Number($("interval").value), website: $("website").value,
    upload_token: $("upload-token").value, all_channels: $("all-channels").checked,
    selected: [...selected]};
}
async function action(path, value) {
  $("error").hidden = true;
  try {
    await api(path, value);
    $("discord-token").value = ""; $("upload-token").value = "";
    await refresh();
  } catch (error) { fail(error); }
}
$("settings").addEventListener("submit", event => {
  event.preventDefault();
  try { action("/api/start", settings()); } catch (error) { fail(error); }
});
$("discover").addEventListener("click", () => {try {action("/api/discover", settings());} catch(error) {fail(error);}});
$("stop").addEventListener("click", () => action("/api/stop", {}));
$("select-visible").addEventListener("click", () => {for (const channel of visibleChannels()) selected.add(channel.id); renderChannels();});
$("refresh").addEventListener("click", () => refresh().catch(fail));
$("filter-text").addEventListener("input", renderChannels);
$("filter-status").addEventListener("change", renderChannels);
$("message-search").addEventListener("input", renderMessages);
$('more-exports').addEventListener('click', () => loadExports(false).catch(fail));
$('upload-export').addEventListener('click', async () => {
  const file = $('export-file').files[0];
  if (!file) return fail(new Error('Choose a DiscordChatExporter JSON file first.'));
  if (file.size > 8000000) return fail(new Error('File exceeds 8 MB. Use the Windows partitioning uploader.'));
  $('upload-export').disabled = true;
  try {
    const response = await fetch('/api/exports', {method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:file});
    const value = await response.json();
    if (!response.ok) throw new Error(value.error || `Upload failed (${response.status})`);
    $('error').hidden = true; await loadExports();
  } catch(error) {fail(error);} finally {$('upload-export').disabled = false;}
});
$("export-prompt").addEventListener("click", async () => {
  try {
    const response = await fetch('/api/export-prompt', {method:'POST', headers:{'X-Local-Key':localKey,'Content-Type':'application/json'}, body:JSON.stringify({selected:[...selected],include_messages:$("prompt-messages").checked})});
    if (!response.ok) {const value=await response.json();throw new Error(value.error || 'Prompt export failed');}
    const file = await response.blob(), url=URL.createObjectURL(file), link=element('a');
    link.href=url;link.download='deepseek-discord-backup-prompt.md';link.click();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  } catch(error) {fail(error);}
});
(async () => {
  const mode = await api("/api/mode"); local = mode.local;
  $("mode").textContent = local ? "ON THIS COMPUTER" : "PRIVATE CLOUD DASHBOARD";
  for (const id of ["local-controls", "log-panel", "selection-heading", "select-visible"]) $(id).hidden = !local;
  $('exporter-panel').hidden = local;
  if (local) $("folder").value = mode.default_folder;
  await refresh();
  setInterval(() => refresh().catch(fail), local ? 4000 : 60000);
})().catch(fail);
