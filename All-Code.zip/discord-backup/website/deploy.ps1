param([string]$Config = "wrangler.jsonc")
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if ((Get-Content $Config -Raw).Contains("REPLACE_WITH_EXISTING_EXPORTS_NAMESPACE_ID")) {
    throw "Set the existing EXPORTS namespace ID and your dashboard username in $Config first. Reuse your existing namespace to preserve saved exports."
}
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    throw "Install Node.js LTS from https://nodejs.org/ before deploying. The backup EXE itself does not need Node.js."
}
& npm.cmd ci --ignore-scripts
if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed." }
& npx.cmd --no-install wrangler login
if ($LASTEXITCODE -ne 0) { throw "Cloudflare login did not complete." }
Write-Host "Confirm this is the Cloudflare account you want to use:"
& npx.cmd --no-install wrangler whoami
if ($LASTEXITCODE -ne 0) { throw "Could not verify Cloudflare login." }
$config = Get-Content $Config -Raw
if ($config.Contains("REPLACE_WITH_YOUR_KV_NAMESPACE_ID")) {
    Write-Host "Creating the dashboard's KV storage namespace."
    & npx.cmd --no-install wrangler kv namespace create discord-private-backup --binding BACKUP_KV --update-config --config $Config
    if ($LASTEXITCODE -ne 0) { throw "Storage creation failed; inspect existing namespaces before retrying." }
    $config = Get-Content $Config -Raw
    if ($config.Contains("REPLACE_WITH_YOUR_KV_NAMESPACE_ID")) {
        throw "Set BACKUP_KV's id in wrangler.jsonc to the created namespace ID, then rerun this script."
    }
}
Write-Host "Deploying a private dashboard. It returns setup-incomplete until both secrets are set."
& node build-inline-assets.mjs
if ($LASTEXITCODE -ne 0) { throw "Website asset build failed." }
& npx.cmd --no-install wrangler deploy --config $Config
if ($LASTEXITCODE -ne 0) { throw "Deployment failed." }
Write-Host "Choose a NEW dashboard password, at least 16 characters. This is NOT your Discord or Cloudflare password."
& npx.cmd --no-install wrangler secret put DASHBOARD_PASSWORD --config $Config
if ($LASTEXITCODE -ne 0) { throw "Dashboard password setup failed." }
Write-Host "Choose a separate random upload token, at least 32 characters. Save it in your password manager and enter it locally in the backup app."
& npx.cmd --no-install wrangler secret put UPLOAD_TOKEN --config $Config
if ($LASTEXITCODE -ne 0) { throw "Upload token setup failed." }
Write-Host "Deployment steps completed. Visit the workers.dev URL printed above."
Write-Host "Dashboard login name: the DASHBOARD_EMAIL value in $Config"
Write-Host "Use the NEW dashboard password, not your account password."
