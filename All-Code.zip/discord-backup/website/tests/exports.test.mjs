import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker.js';
import {validateExport} from '../exports.js';
import {createServer} from 'node:http';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {fileURLToPath} from 'node:url';

const token='test-upload-secret-with-at-least-32-characters';
const password='test-dashboard-password';
const email='test@example.com';
const basic='Basic '+Buffer.from(email+':'+password).toString('base64');
const fixture=()=>({guild:{id:'1',name:'TEST SERVER'},channel:{id:'42',name:'TEST CHANNEL'},dateRange:{after:null,before:null},exportedAt:'2026-11-02T00:00:00Z',messages:[{id:'100',timestamp:'2026-11-01T00:00:00Z',content:'TEST DATA',author:{id:'2',name:'TEST USER'},attachments:[]}],messageCount:1});
function environment() {
  const values=new Map(),metadata=new Map();
  return {UPLOAD_TOKEN:token,DASHBOARD_PASSWORD:password,DASHBOARD_EMAIL:email,
    EXPORTS:{async put(key,value,options={}){values.set(key,value);metadata.set(key,options.metadata);},async get(key){return values.get(key)??null;},async list({prefix='',limit=20,cursor}={}){
      const keys=[...values.keys()].filter(key=>key.startsWith(prefix)).sort(),start=Number(cursor||0),selected=keys.slice(start,start+limit);
      return {keys:selected.map(name=>({name,metadata:metadata.get(name)})),list_complete:start+limit>=keys.length,cursor:String(start+limit)};
    }},values,metadata};
}
const upload=(env,data=fixture(),authorization='Bearer '+token)=>worker.fetch(new Request('https://test.example/',{method:'POST',headers:{Authorization:authorization,'Content-Type':'application/json'},body:JSON.stringify(data)}),env);

test('DCE schema matches observed 2.48 fields and checks actual messageCount',()=>{
  assert.equal(validateExport(fixture()),null);
  assert.match(validateExport({...fixture(),messageCount:99}),/messageCount/);
  assert.match(validateExport({...fixture(),messages:{}}),/array/);
  assert.equal(validateExport({...fixture(),messages:[],messageCount:0}),null);
});
test('anonymous upload is rejected and either token or private dashboard login can upload',async()=>{
  const env=environment();
  assert.equal((await upload(env,fixture(),'')).status,401);
  assert.equal((await upload(env)).status,200);
  assert.equal((await upload(env,fixture(),basic)).status,200);
});
test('full export round-trips, records are idempotent, and export reads require dashboard login',async()=>{
  const env=environment(),first=await upload(env),saved=await first.json();
  assert.equal(saved.messages,1);assert.equal(saved.sha256.length,64);
  assert.equal((await upload(env)).status,200);assert.equal(env.values.size,1);
  assert.equal((await worker.fetch(new Request('https://test.example/api/exports'),env)).status,401);
  const listed=await worker.fetch(new Request('https://test.example/api/exports',{headers:{Authorization:basic}}),env);
  const value=await listed.json();assert.equal(value.exports[0].channel,'TEST CHANNEL');
  const result=await worker.fetch(new Request('https://test.example/api/exports/'+encodeURIComponent(saved.key),{headers:{Authorization:basic}}),env);
  assert.deepEqual(await result.json(),fixture());assert.match(result.headers.get('Content-Disposition'),/attachment/);
});
test('independent simultaneous uploads do not lose exports and paginated listing covers all',async()=>{
  const env=environment();
  const items=Array.from({length:5},(_,n)=>({...fixture(),channel:{id:String(42+n),name:'TEST '+n}}));
  const results=await Promise.all(items.map(data=>upload(env,data)));
  assert.ok(results.every(response=>response.status===200));assert.equal(env.values.size,5);
  let cursor='',count=0;
  do {
    const url='https://test.example/api/exports?limit=2'+(cursor?'&cursor='+cursor:'');
    const page=await (await worker.fetch(new Request(url,{headers:{Authorization:basic}}),env)).json();
    count+=page.exports.length;cursor=page.cursor;
  }while(cursor);
  assert.equal(count,5);
});
test('legacy exports from the supplied Worker remain listable without metadata',async()=>{
  const env=environment();await env.EXPORTS.put('export:42:1762040000000',JSON.stringify(fixture()));
  const response=await worker.fetch(new Request('https://test.example/api/exports?channelId=42',{headers:{Authorization:basic}}),env);
  const result=await response.json();assert.equal(result.exports[0].legacy,true);assert.equal(result.exports[0].messageCount,1);
});
test('rejects malformed JSON, forged counts, oversize bodies and arbitrary KV reads',async()=>{
  const env=environment();
  assert.equal((await upload(env,{...fixture(),messageCount:100})).status,400);
  const malformed=new Request('https://test.example/',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:'{'});
  assert.equal((await worker.fetch(malformed,env)).status,400);
  const large=new Request('https://test.example/',{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json','Content-Length':'8000001'},body:'{}'});
  assert.equal((await worker.fetch(large,env)).status,413);
  assert.equal((await worker.fetch(new Request('https://test.example/api/exports/latest',{headers:{Authorization:basic}}),env)).status,400);
});
test('Unicode metadata fits KV limits and full names are retained in stored JSON',async()=>{
  const env=environment(),data={...fixture(),guild:{id:'1',name:'⚡'.repeat(100)},channel:{id:'42',name:'🔥'.repeat(100)}};
  const response=await upload(env,data);const result=await response.json();assert.equal(response.status,200);
  assert.ok(Buffer.byteLength(JSON.stringify(env.metadata.get(result.key)))<1024);
  assert.equal(JSON.parse(env.values.get(result.key)).guild.name,data.guild.name);
});
test('readiness uses upload authorization and embedded assets work with EXPORTS-only binding',async()=>{
  const env=environment();
  assert.equal((await worker.fetch(new Request('https://test.example/api/upload-status'),env)).status,401);
  const ready=await worker.fetch(new Request('https://test.example/api/upload-status',{headers:{Authorization:'Bearer '+token}}),env);
  assert.equal((await ready.json()).format,'DiscordChatExporter');
  const page=await worker.fetch(new Request('https://test.example/',{headers:{Authorization:basic}}),env);
  assert.equal(page.status,200);assert.match(await page.text(),/DiscordChatExporter uploads/);
});
test('Unicode dashboard passwords authenticate through UTF-8 Basic auth',async()=>{
  const env=environment();env.DASHBOARD_PASSWORD='long-test-password-⚡🔥';
  const authorization='Basic '+Buffer.from(email+':'+env.DASHBOARD_PASSWORD).toString('base64');
  assert.equal((await worker.fetch(new Request('https://test.example/api/exports',{headers:{Authorization:authorization}}),env)).status,200);
});
test('Python uploader to actual HTTP Worker bridge confirms checksums and resumes',async t=>{
  const env=environment();
  const server=createServer(async(req,res)=>{
    const chunks=[];for await(const chunk of req)chunks.push(chunk);
    const init={method:req.method,headers:req.headers};if(req.method!=='GET')init.body=Buffer.concat(chunks);
    const response=await worker.fetch(new Request('http://127.0.0.1'+req.url,init),env);
    res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const script=`import json,tempfile,urllib.request,urllib.parse,sys\nfrom pathlib import Path\nfrom upload_exports import Progress,upload_file,upload,check_receiver\nport=sys.argv[1];token=sys.argv[2]\nclient=urllib.request.build_opener(urllib.request.ProxyHandler({}))\ndef opener(request,timeout):\n path=urllib.parse.urlsplit(request.full_url).path\n local=urllib.request.Request('http://127.0.0.1:'+port+path,data=request.data,headers=dict(request.header_items()),method=request.get_method())\n return client.open(local,timeout=timeout)\ncheck_receiver('https://test.invalid',token,opener)\nwith tempfile.TemporaryDirectory() as folder:\n path=Path(folder)/'test.json'\n path.write_text(json.dumps({'guild':{'id':'1','name':'TEST SERVER'},'channel':{'id':'42','name':'TEST CHANNEL'},'messageCount':0,'messages':[]}))\n progress=Progress(Path(folder)/'progress.json')\n send=lambda body,endpoint,secret:upload(body,endpoint,secret,opener)\n assert upload_file(path,'https://test.invalid',token,progress,lambda message:None,send)==1\n assert upload_file(path,'https://test.invalid',token,Progress(progress.path),lambda message:None,send)==0\n print('Cross-language upload, checksum and resume passed')\n`;
  const {stdout}=await promisify(execFile)('python3',['-c',script,String(server.address().port),token],{cwd:fileURLToPath(new URL('../../',import.meta.url))});
  assert.match(stdout,/checksum and resume passed/);assert.equal(env.values.size,1);
});
