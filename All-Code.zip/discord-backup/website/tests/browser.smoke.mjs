// Real Chromium test using CDP; no browser automation dependencies.
import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
import {mkdtemp,rm,writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';

const project=fileURLToPath(new URL('../../',import.meta.url));
const temp=await mkdtemp(join(tmpdir(),'discord-backup-browser-'));
let browser,fixture,cloudFixture,ws;
function waitForLine(stream,pattern) {
  return new Promise((resolve,reject)=>{
    let buffer='';const timer=setTimeout(()=>reject(new Error('Timed out waiting for subprocess readiness')),20000);
    stream.on('data',chunk=>{
      buffer+=chunk.toString();const match=buffer.match(pattern);
      if(match){clearTimeout(timer);resolve(match[1]);}
    });
    stream.on('error',reject);
  });
}
try {
  fixture=spawn('python3',['tests/serve_fixture.py'],{cwd:project,stdio:['ignore','pipe','pipe']});
  let fixtureErrors='';fixture.stderr.on('data',data=>fixtureErrors+=data.toString());
  const url=await waitForLine(fixture.stdout,/"url": "([^"]+)"/);
  browser=spawn('chromium',['--headless','--no-sandbox','--disable-dev-shm-usage','--no-proxy-server', '--disable-background-networking','--remote-debugging-port=0','--user-data-dir='+temp,'about:blank'],{stdio:['ignore','ignore','pipe']});
  const endpoint=await waitForLine(browser.stderr,/DevTools listening on (ws:\/\/[^\s]+)/);
  ws=new WebSocket(endpoint);
  await new Promise((resolve,reject)=>{ws.onopen=resolve;ws.onerror=reject;});
  let sequence=0;const pending=new Map();
  ws.onmessage=event=>{
    const message=JSON.parse(event.data);
    if(message.id&&pending.has(message.id)){
      const {resolve,reject,timer}=pending.get(message.id);pending.delete(message.id);clearTimeout(timer);
      if(message.error)reject(new Error(JSON.stringify(message.error)));else resolve(message.result);
    }
  };
  const send=(method,params={},sessionId)=>new Promise((resolve,reject)=>{
    const id=++sequence,timer=setTimeout(()=>{pending.delete(id);reject(new Error('CDP timeout: '+method));},15000);
    pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params,sessionId}));
  });
  const {targetId}=await send('Target.createTarget',{url});
  const {sessionId}=await send('Target.attachToTarget',{targetId,flatten:true});
  await send('Runtime.enable',{},sessionId);
  const evaluate=async expression=>{
    const result=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},sessionId);
    if(result.exceptionDetails)throw new Error(JSON.stringify(result.exceptionDetails));
    return result.result.value;
  };
  await evaluate(`new Promise((resolve,reject)=>{let n=0;const t=setInterval(()=>{if(document.getElementById('total')?.textContent==='3'){clearInterval(t);resolve(true);}else if(++n>150){clearInterval(t);reject(new Error('Dashboard did not render'));}},100);})`);
  const counts=await evaluate(`({total:document.getElementById('total').textContent,checked:document.getElementById('checked').textContent,unchecked:document.getElementById('unchecked').textContent,failed:document.getElementById('failed').textContent,account:document.getElementById('account').textContent,rows:document.querySelectorAll('#channels tr').length,unsafe:globalThis.UNSAFE_EXECUTED===true})`);
  assert.deepEqual({...counts,account:undefined},{total:'3',checked:'2',unchecked:'1',failed:'1',account:undefined,rows:3,unsafe:false});
  assert.match(counts.account,/SYNTHETIC DATA/);
  assert.equal(await evaluate(`document.getElementById('messages').textContent.includes('<script>globalThis.UNSAFE_EXECUTED=true</script>')`),true);
  await evaluate(`document.getElementById('filter-status').value='Unchecked';document.getElementById('filter-status').dispatchEvent(new Event('change'));`);
  assert.equal(await evaluate(`document.querySelectorAll('#channels tr').length`),1);
  assert.match(await evaluate(`document.getElementById('channels').textContent`),/unchecked TEST channel/);
  await evaluate(`document.getElementById('select-visible').click()`);
  assert.equal(await evaluate(`document.querySelector('#channels input').checked`),true);
  await evaluate(`document.getElementById('filter-status').value='Failed';document.getElementById('filter-status').dispatchEvent(new Event('change'));`);
  assert.match(await evaluate(`document.getElementById('channels').textContent`),/TEST permission denial/);
  assert.equal(await evaluate(`document.getElementById('local-controls').hidden`),false);
  assert.match(await evaluate(`document.getElementById('logs').textContent`),/SYNTHETIC TEST RUN/);
  assert.equal(await evaluate(`document.getElementById('error').hidden`),true);
  const exported=await evaluate(`(async()=>{const response=await fetch('/api/export-prompt',{method:'POST',headers:{'X-Local-Key':sessionStorage.getItem('backup-local-key'),'Content-Type':'application/json'},body:JSON.stringify({include_messages:true,selected:[]})});return {status:response.status,text:await response.text()};})()`);
  assert.equal(exported.status,200);
  assert.match(exported.text,/SYNTHETIC TEST RUN/);
  assert.match(exported.text,/TEST MESSAGE/);
  assert.match(exported.text,/No AI service was contacted/);
  if(process.env.BACKUP_SCREENSHOT){
    await evaluate(`document.getElementById('filter-status').value='All channels';document.getElementById('filter-status').dispatchEvent(new Event('change'));`);
    await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1300,deviceScaleFactor:1,mobile:false},sessionId);
    const shot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true},sessionId);
    await writeFile(process.env.BACKUP_SCREENSHOT,Buffer.from(shot.data,'base64'));
  }
  console.log('PASS: Chromium rendered account identity, coverage counts, checked/unchecked filters, last-check results, selection, logs, escaped message content, and a downloadable DeepSeek prompt. All data was synthetic.');
  assert.equal(fixtureErrors,'');
  cloudFixture=spawn('node',['tests/serve_cloud_fixture.mjs'],{cwd:fileURLToPath(new URL('../',import.meta.url)),stdio:['ignore','pipe','pipe']});
  const cloudURL=await waitForLine(cloudFixture.stdout,/"url":"([^"]+)"/);
  const {targetId:cloudTarget}=await send('Target.createTarget',{url:'about:blank'});
  const {sessionId:cloudSession}=await send('Target.attachToTarget',{targetId:cloudTarget,flatten:true});
  await send('Network.enable',{},cloudSession);
  await send('Network.setExtraHTTPHeaders',{headers:{Authorization:'Basic '+Buffer.from('test@example.com:cloud-fixture-password').toString('base64')}},cloudSession);
  await send('Page.navigate',{url:cloudURL},cloudSession);
  const cloudEval=async expression=>{
    const value=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},cloudSession);
    if(value.exceptionDetails)throw new Error(JSON.stringify(value.exceptionDetails));
    return value.result.value;
  };
  await cloudEval(`new Promise((resolve,reject)=>{let n=0;const timer=setInterval(()=>{if(document.querySelectorAll('#saved-exports tr').length===1){clearInterval(timer);resolve(true);}else if(++n>150){clearInterval(timer);reject(new Error('Cloud exports did not render'));}},100);})`);
  assert.equal(await cloudEval(`document.getElementById('exporter-panel').hidden`),false);
  assert.match(await cloudEval(`document.getElementById('saved-exports').textContent`),/SYNTHETIC EXPORTED CHANNEL/);
  const uploadPath=join(temp,'synthetic-export.json');
  await writeFile(uploadPath,JSON.stringify({guild:{id:'1',name:'SYNTHETIC CLOUD SERVER'},channel:{id:'43',name:'SECOND SYNTHETIC CHANNEL'},messageCount:0,messages:[]}));
  const {root:dom}=await send('DOM.getDocument',{},cloudSession);
  const {nodeId}=await send('DOM.querySelector',{nodeId:dom.nodeId,selector:'#export-file'},cloudSession);
  await send('DOM.setFileInputFiles',{nodeId,files:[uploadPath]},cloudSession);
  await cloudEval(`document.getElementById('upload-export').click()`);
  await cloudEval(`new Promise((resolve,reject)=>{let n=0;const timer=setInterval(()=>{if(document.querySelectorAll('#saved-exports tr').length===2){clearInterval(timer);resolve(true);}else if(++n>150){clearInterval(timer);reject(new Error('Browser JSON upload failed'));}},100);})`);
  assert.match(await cloudEval(`document.getElementById('saved-exports').textContent`),/SECOND SYNTHETIC CHANNEL/);
  assert.equal(await cloudEval(`document.getElementById('error').hidden`),true);
  console.log('PASS: Chromium authenticated to the Worker, listed stored exports, selected a JSON file, uploaded it, and displayed the new record. All data was synthetic.');
} finally {
  ws?.close();browser?.kill('SIGTERM');fixture?.kill('SIGTERM');cloudFixture?.kill('SIGTERM');
  await new Promise(resolve=>setTimeout(resolve,300));
  await rm(temp,{recursive:true,force:true});
}
