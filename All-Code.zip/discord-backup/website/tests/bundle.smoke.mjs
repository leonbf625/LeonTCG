import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const {default:worker}=await import(pathToFileURL(resolve(process.argv[2])).href);
const values=new Map();
const env={DASHBOARD_EMAIL:'test@example.com',DASHBOARD_PASSWORD:'test-password-at-least-16',UPLOAD_TOKEN:'test-upload-token-at-least-32-characters',
  EXPORTS:{async get(key){return values.get(key)??null;},async put(key,value){values.set(key,value);},async list(){return {keys:[],list_complete:true};}}};
const authorization='Basic '+Buffer.from(env.DASHBOARD_EMAIL+':'+env.DASHBOARD_PASSWORD).toString('base64');
const response=await worker.fetch(new Request('https://test.invalid/',{headers:{Authorization:authorization}}),env);
assert.equal(response.status,200);assert.match(await response.text(),/DiscordChatExporter uploads/);
assert.equal((await worker.fetch(new Request('https://test.invalid/'),env)).status,401);
const saved=await worker.fetch(new Request('https://test.invalid/',{method:'POST',headers:{Authorization:'Bearer '+env.UPLOAD_TOKEN,'Content-Type':'application/json'},body:JSON.stringify({guild:{id:'1',name:'TEST'},channel:{id:'2',name:'TEST'},messages:[],messageCount:0})}),env);
assert.equal(saved.status,200);assert.equal((await saved.json()).success,true);assert.equal(values.size,1);
console.log('Standalone Worker bundle passed: embedded private website and JSON upload work with EXPORTS and no ASSETS binding. Synthetic data only.');
