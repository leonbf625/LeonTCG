// Synthetic exports only. No Discord or Cloudflare credentials are used.
import {createServer} from 'node:http';
import worker from '../worker.js';
const values=new Map(),metadata=new Map();
const env={DASHBOARD_EMAIL:'test@example.com',DASHBOARD_PASSWORD:'cloud-fixture-password',UPLOAD_TOKEN:'cloud-fixture-upload-token-1234567890123456',
  EXPORTS:{async get(key){return values.get(key)??null;},async put(key,value,options={}){values.set(key,value);metadata.set(key,options.metadata);},async list({prefix='',limit=20}={}){
    const keys=[...values.keys()].filter(key=>key.startsWith(prefix)).sort();
    return {keys:keys.slice(0,limit).map(name=>({name,metadata:metadata.get(name)})),list_complete:true};
  }}};
await worker.fetch(new Request('https://test.invalid/',{method:'POST',headers:{Authorization:'Bearer '+env.UPLOAD_TOKEN,'Content-Type':'application/json'},body:JSON.stringify({guild:{id:'1',name:'SYNTHETIC CLOUD SERVER'},channel:{id:'42',name:'SYNTHETIC EXPORTED CHANNEL'},exportedAt:'2026-11-02T00:00:00Z',messageCount:0,messages:[]})}),env);
const server=createServer(async(req,res)=>{
  const chunks=[];for await(const chunk of req)chunks.push(chunk);
  const init={method:req.method,headers:req.headers};if(req.method!=='GET'&&req.method!=='HEAD')init.body=Buffer.concat(chunks);
  const response=await worker.fetch(new Request('http://127.0.0.1'+req.url,init),env);
  res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
console.log(JSON.stringify({url:'http://127.0.0.1:'+server.address().port}));
