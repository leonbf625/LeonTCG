import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import worker from '../worker.js';

const password = 'test-only-password-123456';
const uploadToken = 'test-only-upload-token-1234567890123456';
const email = 'test@example.com';
const auth = 'Basic ' + Buffer.from(email + ':' + password).toString('base64');
function environment() {
  const data = new Map();
  return {DASHBOARD_EMAIL: email, DASHBOARD_PASSWORD: password, UPLOAD_TOKEN: uploadToken,
    BACKUP_KV: {async get(key) {return data.get(key) ?? null;}, async put(key,value) {data.set(key,value);}},
    ASSETS: {async fetch(request) {
      const path = new URL(request.url).pathname;
      const allowed = {'/': ['index.html', 'text/html'], '/app.js': ['app.js','text/javascript'], '/style.css': ['style.css','text/css']};
      if (!allowed[path]) return new Response('Not found', {status:404});
      return new Response(await readFile(new URL('../public/' + allowed[path][0], import.meta.url)), {headers:{'Content-Type':allowed[path][1]}});
    }}
  };
}
function snapshot() {
  return {created_at: new Date().toISOString(), account: {id:'1',username:'TEST ACCOUNT'}, channels:[
    {id:'42',guild:'TEST SERVER',channel:'CHECKED TEST CHANNEL',status:'history backed up',last_checked_at:new Date().toISOString(),messages:1},
    {id:'43',guild:'TEST SERVER',channel:'UNCHECKED TEST CHANNEL',status:'not started',last_checked_at:null,messages:0}
  ], recent_messages:[{id:'100',channel_id:'42',author:'TEST USER',timestamp:new Date().toISOString(),content:'TEST DATA ONLY <script>alert(1)</script>'}]};
}

test('fails closed without configured secrets', async () => {
  const response = await worker.fetch(new Request('https://test.example/'), {});
  assert.equal(response.status,503);
});
test('protects assets and reports; upload credential does not grant read access', async () => {
  const env=environment();
  for (const path of ['/', '/app.js', '/api/report']) {
    assert.equal((await worker.fetch(new Request('https://test.example'+path),env)).status,401);
  }
  const response = await worker.fetch(new Request('https://test.example/api/report',{headers:{Authorization:'Bearer '+uploadToken}}),env);
  assert.equal(response.status,401);
});
test('rejects invalid auth, payloads, and oversized uploads', async () => {
  const env=environment();
  const req=(data,extra={})=>new Request('https://test.example/api/sync',{method:'POST',headers:{Authorization:'Bearer '+uploadToken,'Content-Type':'application/json',...extra},body:JSON.stringify(data)});
  assert.equal((await worker.fetch(req({}),env)).status,400);
  assert.equal((await worker.fetch(req(snapshot(),{Authorization:'Bearer wrong'}),env)).status,401);
  assert.equal((await worker.fetch(req(snapshot(),{'Content-Length':'2000001'}),env)).status,413);
  assert.equal((await worker.fetch(req({...snapshot(),recent_messages:new Array(201).fill(snapshot().recent_messages[0])}),env)).status,400);
});
test('upload persists only allowed fields and authenticated report reads them', async () => {
  const env=environment(), value={...snapshot(),token:'DO NOT STORE',events:[{detail:'PRIVATE LOCAL LOG'}]};
  const response=await worker.fetch(new Request('https://test.example/api/sync',{method:'POST',headers:{Authorization:'Bearer '+uploadToken,'Content-Type':'application/json'},body:JSON.stringify(value)}),env);
  assert.equal(response.status,200); assert.equal((await response.json()).ok,true);
  const report=await worker.fetch(new Request('https://test.example/api/report',{headers:{Authorization:auth}}),env);
  const text=await report.text(); assert.ok(!text.includes('DO NOT STORE')); assert.ok(!text.includes('PRIVATE LOCAL LOG'));
  assert.equal(JSON.parse(text).channels.length,2);
});
test('real local HTTP smoke: upload, private read, assets and browser mode', async t => {
  const env=environment();
  const server=createServer(async (req,res)=>{
    const chunks=[];for await(const chunk of req)chunks.push(chunk);
    const init={method:req.method,headers:req.headers};
    if(req.method!=='GET'&&req.method!=='HEAD')init.body=Buffer.concat(chunks);
    const response=await worker.fetch(new Request('http://127.0.0.1'+req.url,init),env);
    res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const base='http://127.0.0.1:'+server.address().port;
  assert.equal((await fetch(base+'/api/report')).status,401);
  const posted=await fetch(base+'/api/sync',{method:'POST',headers:{Authorization:'Bearer '+uploadToken,'Content-Type':'application/json'},body:JSON.stringify(snapshot())});
  assert.equal(posted.status,200);
  const report=await fetch(base+'/api/report',{headers:{Authorization:auth}});
  const body=await report.json(); assert.equal(body.account.username,'TEST ACCOUNT');
  assert.equal(body.channels.filter(channel=>channel.last_checked_at).length,1);
  assert.equal(body.channels.filter(channel=>!channel.last_checked_at).length,1);
  const page=await fetch(base+'/',{headers:{Authorization:auth}});
  assert.equal(page.status,200); assert.match(await page.text(),/Channel coverage/);
  assert.match(page.headers.get('Content-Security-Policy'),/frame-ancestors 'none'/);
  const mode=await fetch(base+'/api/mode',{headers:{Authorization:auth}});
  assert.equal((await mode.json()).local,false);
});
