# Upgrade the existing DiscordChatExporter receiver

Target: `https://your-worker.workers.dev/`.

The supplied Worker only accepts POST and writes exports to KV. It does not log
in to Discord, scan channels, or display a website on GET. Its array index can
lose entries during simultaneous uploads; trimming the index does not delete
old stored JSON. These changes are prepared locally; they have not been deployed
to your account.

## Update through the Cloudflare editor

1. Open your Cloudflare dashboard and select Worker **your-export-receiver**.
2. Keep its existing **EXPORTS** KV binding and namespace. Do not remove or recreate
   it. The updated code can list the old `export:<channelId>:<timestamp>` records.
3. Add a non-secret `DASHBOARD_EMAIL` variable (the login name you choose), and
   securely add **two new secrets** in Worker settings:
   - `DASHBOARD_PASSWORD`: at least 16 characters, distinct from your account passwords.
   - `UPLOAD_TOKEN`: at least 32 random characters, distinct from the dashboard password
     and Discord account token. Save it in your password manager.
4. Replace the Worker code with the complete generated **Cloudflare-Receiver.js**
   file distributed with this update. It is a single ES module with the website
   embedded; an ASSETS binding is optional. Deploy it using Cloudflare's editor.
5. Visit the site. It should request the dashboard login, then show saved exports.
   A response saying setup is incomplete means a binding or variable is missing.

Do not paste secrets into chat, source code, or GitHub. This dashboard login is
separate from Discord OAuth, Google login, and your Cloudflare account login.

For CLI deployment, first set the existing namespace ID and desired login name
in `wrangler.export.jsonc`, then run:

```powershell
.\deploy.ps1 -Config wrangler.export.jsonc
```

The single-file receiver is generated with:

```sh
node build-inline-assets.mjs
npx wrangler deploy --config wrangler.export.jsonc --dry-run --outdir ../artifacts/receiver-bundle
```

## Upload from Windows without installing Python

Extract the updated Windows test bundle. In PowerShell beside the EXE:

```powershell
.\DiscordLocalBackup-Windows-x64.exe --upload-exports --website "https://your-worker.workers.dev/" --folder "C:\DiscordExports" --watch
```

Or run **Upload Exports.cmd** for a one-time interactive upload. Supply the
Worker's separate UPLOAD_TOKEN when prompted locally. The tool checks the
receiver version before sending private export data. It does not use a Discord
token and does not itself collect Discord messages.

Use DiscordChatExporter to save **JSON output** into the watched folder. The
uploaded `DiscordChatExporter-2.48.zip` is source code, not JSON chat data or a
Windows executable. Do not upload that ZIP to the receiver.

Files are partitioned at message boundaries below 7.5 MB per request. The original
exported timestamp and metadata are preserved, and `_upload` identifies the source
hash and partition number. This is an upload partition, not proof of a complete
channel history. Files above 64 MB need exporter partitioning or smaller date ranges.

Confirmed parts are tracked in `%LOCALAPPDATA%\DiscordLocalBackup\upload-state.json`.
Retries use content hashes, and re-uploading exactly the same part stores the same
KV record. State contains hashes and storage keys, never tokens or message text.
Use a separate state file (`--state`) for independent jobs; do not run concurrent
processes writing the same state file. `--force` re-uploads confirmed parts if remote
storage was replaced. The PC must stay awake and the uploader must remain open.

## API and storage limits

- `GET /`: private website with export upload/list/download controls.
- `POST /` or `POST /api/exports`: DiscordChatExporter JSON with Bearer UPLOAD_TOKEN,
  or an authenticated dashboard browser session.
- `GET /api/upload-status`: authenticated capability check with the upload token;
  it cannot read saved exports.
- `GET /api/exports`: dashboard login required, paginated list; optional `channelId`,
  `limit` (1–100), and `cursor` parameters.
- `GET /api/exports/<URL-encoded-key>`: private JSON download.
- Existing `/api/sync` and dashboard overview routes remain compatible with the
  local scanner. EXPORTS can serve as the storage binding when BACKUP_KV is absent.

The Worker accepts up to 8 MB per request, validates actual message counts and
timestamps, and returns SHA-256 receipts. Full JSON is stored; attachment files
are not uploaded. Independent records avoid a shared read/modify/write index.
KV metadata lists are eventually consistent and ordered by key, not receipt time.
The page does not claim a complete or chronological global listing until all pages
are loaded. Old received-at timestamps are shown as unknown if not recorded.

Nothing automatically deletes old exports. Review Cloudflare's free-tier storage
and request quotas; large or frequent exports can exceed them. KV is a private
off-device copy, not a substitute for the original backup files.
