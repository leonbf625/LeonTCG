// DiscordChatExporter JSON storage. Authentication is enforced by worker.js.
export const MAX_EXPORT_BYTES = 8_000_000;
const id = value => typeof value === 'string' && /^\d{1,22}$/.test(value);
const date = value => typeof value === 'string' && Number.isFinite(Date.parse(value));
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);

export function validateExport(data) {
  if (!object(data) || !object(data.guild) || !object(data.channel) || !Array.isArray(data.messages)) return 'Expected guild, channel and messages array';
  if (!id(data.guild.id) || !id(data.channel.id)) return 'Guild and channel IDs must be numeric strings';
  if (typeof data.guild.name !== 'string' || typeof data.channel.name !== 'string' || data.guild.name.length > 256 || data.channel.name.length > 256) return 'Invalid guild or channel name';
  if (data.messageCount !== undefined && (!Number.isSafeInteger(data.messageCount) || data.messageCount !== data.messages.length)) return 'messageCount must match the actual messages array';
  if (data.exportedAt !== undefined && !date(data.exportedAt)) return 'Invalid exportedAt timestamp';
  for (const message of data.messages) {
    if (!object(message) || !id(message.id) || !date(message.timestamp) || typeof message.content !== 'string') return 'Invalid message ID, timestamp or content';
  }
  return null;
}

function reply(data, status = 200) {
  return new Response(JSON.stringify(data), {status, headers: {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
}

function shortName(value) {
  // KV metadata is limited to 1024 bytes. Keep full names in the stored payload.
  let result = '';
  for (const character of value) {
    if (new TextEncoder().encode(result + character).length > 120) break;
    result += character;
  }
  return result;
}

export async function receiveExport(request, storage) {
  if (!(request.headers.get('Content-Type') || '').toLowerCase().startsWith('application/json')) return reply({error:'Content-Type must be application/json'},415);
  if (Number(request.headers.get('Content-Length')) > MAX_EXPORT_BYTES) return reply({error:'Export exceeds 8 MB; use the partitioning uploader'},413);
  const reader = request.body?.getReader();
  if (!reader) return reply({error:'Empty request'},400);
  const parts = [];
  let length = 0;
  while (true) {
    const {done,value} = await reader.read();
    if (done) break;
    length += value.byteLength;
    if (length > MAX_EXPORT_BYTES) { await reader.cancel();return reply({error:'Export exceeds 8 MB; use the partitioning uploader'},413); }
    parts.push(value);
  }
  const bytes = new Uint8Array(length);
  let offset=0;
  for (const part of parts) {bytes.set(part,offset);offset+=part.byteLength;}
  let data;
  try { data=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes)); }
  catch { return reply({error:'Invalid JSON or UTF-8'},400); }
  const invalid=validateExport(data);
  if (invalid) return reply({error:invalid},400);
  const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),byte=>byte.toString(16).padStart(2,'0')).join('');
  const claimed=request.headers.get('Idempotency-Key');
  if (claimed && claimed !== digest) return reply({error:'Idempotency-Key does not match the request SHA-256'},400);
  const key=`export:${data.channel.id}:${digest}`;
  const metadata={key,guild:shortName(data.guild.name),channel:shortName(data.channel.name),channelId:data.channel.id,
    messageCount:data.messages.length,exportedAt:data.exportedAt ?? null,receivedAt:new Date().toISOString(),sha256:digest,bytes:length};
  // Independent content-addressed records avoid lost updates from a shared array index.
  // Exact retries overwrite the same payload; unrelated uploads use different keys.
  await storage.put(key,new TextDecoder().decode(bytes),{metadata});
  return reply({ok:true,success:true,message:'Export received and saved',key,channel:data.channel.name,messages:data.messages.length,sha256:digest});
}

export async function listExports(request,storage) {
  const url=new URL(request.url), channelId=url.searchParams.get('channelId');
  if (channelId !== null && !id(channelId)) return reply({error:'Invalid channelId'},400);
  const limit=Number(url.searchParams.get('limit') || 20);
  if (!Number.isInteger(limit) || limit < 1 || limit > 100) return reply({error:'limit must be 1 to 100'},400);
  const page=await storage.list({prefix:channelId ? `export:${channelId}:` : 'export:',limit,cursor:url.searchParams.get('cursor') || undefined});
  const entries=[];
  for (const record of page.keys) {
    if (record.metadata) { entries.push({...record.metadata,key:record.name});continue; }
    // Read exports created by the originally supplied receiver, which had no KV metadata.
    try {
      const raw=await storage.get(record.name);
      if (!raw) continue;
      const data=JSON.parse(raw);
      entries.push({key:record.name,guild:data.guild?.name || 'Unknown',channel:data.channel?.name || 'Unknown',
        channelId:data.channel?.id || null,messageCount:Array.isArray(data.messages)?data.messages.length:0,
        exportedAt:data.exportedAt || null,receivedAt:null,legacy:true});
    } catch { entries.push({key:record.name,error:'Stored export could not be read'}); }
  }
  return reply({exports:entries,cursor:page.list_complete ? null : page.cursor,
    note:'KV pages are ordered by channel/key, not upload time. All stored exports are retained; no automatic deletion is performed.'});
}

export async function downloadExport(encoded,storage) {
  let key;
  try {key=decodeURIComponent(encoded);} catch {return reply({error:'Invalid export key'},400);}
  if (!/^export:\d{1,22}:(?:[a-f0-9]{64}|\d{10,16})$/.test(key)) return reply({error:'Invalid export key'},400);
  const value=await storage.get(key);
  if (value === null) return reply({error:'Export not found'},404);
  return new Response(value,{headers:{'Content-Type':'application/json; charset=utf-8','Content-Disposition':`attachment; filename="discord-${key.split(':')[1]}.json"`,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
}
