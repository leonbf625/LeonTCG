const headers = {
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "X-Frame-Options": "DENY",
  "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
};

function json(value, status = 200) {
  return new Response(JSON.stringify(value), {status, headers: {...headers, "Content-Type": "application/json"}});
}

async function equals(a, b) {
  const encoder = new TextEncoder();
  const [x, y] = await Promise.all([a, b].map(value => crypto.subtle.digest("SHA-256", encoder.encode(value))));
  const left = new Uint8Array(x), right = new Uint8Array(y);
  let difference = 0;
  for (let i = 0; i < left.length; i++) difference |= left[i] ^ right[i];
  return difference === 0;
}

async function authenticated(request, env) {
  const authorization = request.headers.get("Authorization") || "";
  if (!authorization.startsWith("Basic ")) return false;
  try {
    const text = atob(authorization.slice(6));
    const colon = text.indexOf(":");
    if (colon < 0) return false;
    return (await equals(text.slice(0, colon), env.DASHBOARD_EMAIL)) &&
      (await equals(text.slice(colon + 1), env.DASHBOARD_PASSWORD));
  } catch { return false; }
}

export function validSnapshot(value) {
  if (!value || typeof value !== "object" || !value.account || !/^\d+$/.test(value.account.id)) return false;
  if (typeof value.created_at !== "string" || !Number.isFinite(Date.parse(value.created_at))) return false;
  if (!Array.isArray(value.channels) || value.channels.length > 10000 || !Array.isArray(value.recent_messages) || value.recent_messages.length > 200) return false;
  for (const channel of value.channels) {
    if (!channel || !/^\d+$/.test(channel.id) || typeof channel.channel !== "string" || typeof channel.status !== "string") return false;
    if (channel.last_checked_at != null && !Number.isFinite(Date.parse(channel.last_checked_at))) return false;
  }
  return value.recent_messages.every(message => message && /^\d+$/.test(message.id) && /^\d+$/.test(message.channel_id) && typeof message.content === "string" && message.content.length <= 8000);
}

async function upload(request, env) {
  const authorized = await equals(request.headers.get("Authorization") || "", "Bearer " + env.UPLOAD_TOKEN);
  if (!authorized) return json({error: "Unauthorized"}, 401);
  if (Number(request.headers.get("Content-Length")) > 2000000) return json({error: "Snapshot exceeds 2 MB"}, 413);
  if (!(request.headers.get("Content-Type") || "").startsWith("application/json")) return json({error: "JSON required"}, 415);
  const reader = request.body?.getReader();
  if (!reader) return json({error: "Empty upload"}, 400);
  const chunks = [];
  let total = 0;
  while (true) {
    const {done, value} = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > 2000000) {
      await reader.cancel();
      return json({error: "Snapshot exceeds 2 MB"}, 413);
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {bytes.set(chunk, offset); offset += chunk.byteLength;}
  let snapshot;
  try { snapshot = JSON.parse(new TextDecoder().decode(bytes)); }
  catch { return json({error: "Invalid JSON"}, 400); }
  if (!validSnapshot(snapshot)) return json({error: "Invalid snapshot"}, 400);
  // Allow only the dashboard's bounded fields; never store request headers or credentials.
  const clean = {
    created_at: snapshot.created_at,
    uploaded_at: new Date().toISOString(),
    account: {id: snapshot.account.id, username: String(snapshot.account.username || "Unknown"), global_name: snapshot.account.global_name || null},
    channels: snapshot.channels.map(channel => Object.fromEntries([
      "id", "guild_id", "guild", "channel", "status", "error", "last_started_at", "last_checked_at", "last_success_at", "messages", "attachments", "downloaded", "attachment_errors", "checked", "history_complete"
    ].map(key => [key, channel[key] ?? null]))),
    recent_messages: snapshot.recent_messages.map(message => ({
      id: message.id, channel_id: message.channel_id, author: String(message.author || "Unknown"),
      timestamp: message.timestamp || null, content: message.content
    })),
    message_scope: "Most recent 200 archived messages; full history and attachments remain on the Windows PC."
  };
  await env.BACKUP_KV.put("latest", JSON.stringify(clean));
  return json({ok: true, uploaded_at: clean.uploaded_at});
}

export default {
  async fetch(request, env) {
    if (!env.BACKUP_KV || !env.DASHBOARD_EMAIL || !env.DASHBOARD_PASSWORD || env.DASHBOARD_PASSWORD.length < 16 || !env.UPLOAD_TOKEN || env.UPLOAD_TOKEN.length < 32) {
      return json({error: "Dashboard setup incomplete. Set storage, dashboard password (16+ characters), and upload token (32+ characters)."}, 503);
    }
    const url = new URL(request.url);
    try {
      if (url.pathname === "/api/sync" && request.method === "POST") return await upload(request, env);
      if (!(await authenticated(request, env))) {
        return new Response("Private backup dashboard. Sign in using your dashboard email and separate dashboard password.", {
          status: 401, headers: {...headers, "WWW-Authenticate": 'Basic realm="Private Discord backup", charset="UTF-8"'}
        });
      }
      if (request.method !== "GET") return json({error: "Method not allowed"}, 405);
      if (url.pathname === "/api/mode") return json({local: false});
      if (url.pathname === "/api/state") return json({busy: false, logs: [], status: "Private cloud dashboard"});
      if (url.pathname === "/api/report") {
        const report = await env.BACKUP_KV.get("latest");
        return report ? new Response(report, {headers: {...headers, "Content-Type": "application/json"}}) : json({channels: [], recent_messages: [], account: null});
      }
      if (url.pathname.startsWith("/api/")) return json({error: "Not found"}, 404);
      const response = await env.ASSETS.fetch(request);
      const protectedResponse = new Response(response.body, response);
      for (const [key, value] of Object.entries(headers)) protectedResponse.headers.set(key, value);
      return protectedResponse;
    } catch { return json({error: "Storage or request failed; retry later"}, 503); }
  }
};
