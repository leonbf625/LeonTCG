"""Upload DiscordChatExporter JSON files; optionally watch a folder for new exports."""
from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import os
from pathlib import Path
import time
import urllib.error
import urllib.parse
import urllib.request

from sync import NoRedirect

MAX_FILE_BYTES = 64_000_000
MAX_PART_BYTES = 7_500_000


def encode(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')


def partitions(raw, max_bytes=MAX_PART_BYTES):
    if len(raw) > MAX_FILE_BYTES:
        raise ValueError('File exceeds 64 MB. Use DiscordChatExporter file partitioning or a smaller date range.')
    def invalid_constant(value):
        raise ValueError('Non-finite numbers are not valid JSON')
    try:
        data = json.loads(raw.decode('utf-8-sig'), parse_constant=invalid_constant)
    except (UnicodeError, ValueError):
        raise ValueError('Not valid UTF-8 JSON; the exporter may still be writing the file') from None
    if not isinstance(data, dict) or not isinstance(data.get('guild'), dict) or not isinstance(data.get('channel'), dict) or not isinstance(data.get('messages'), list):
        raise ValueError('Expected a DiscordChatExporter JSON object with guild, channel and messages')
    for part in ('guild', 'channel'):
        if not isinstance(data[part].get('id'), str) or not data[part]['id'].isdigit() or not isinstance(data[part].get('name'), str):
            raise ValueError('Invalid guild/channel metadata')
    if 'messageCount' in data and (type(data['messageCount']) is not int or data['messageCount'] != len(data['messages'])):
        raise ValueError('messageCount differs from the actual messages array')
    header = {key: value for key, value in data.items() if key not in ('messages', 'messageCount', '_upload')}
    header['_upload'] = {'sourceSha256': hashlib.sha256(raw).hexdigest(), 'part': 0, 'parts': 0}
    overhead = len(encode({**header, 'messages': [], 'messageCount': 0})) + 128
    if overhead >= max_bytes:
        raise ValueError('Export metadata exceeds the upload size limit')
    groups, current, size = [], [], overhead
    for message in data['messages']:
        if not isinstance(message, dict) or not isinstance(message.get('id'), str) or not message['id'].isdigit():
            raise ValueError('A message has an invalid ID')
        length = len(encode(message)) + 1
        if overhead + length > max_bytes:
            raise ValueError('One message exceeds the upload size limit; it was not truncated')
        if current and size + length > max_bytes:
            groups.append(current)
            current, size = [], overhead
        current.append(message)
        size += length
    if current or not groups:
        groups.append(current)
    for number, messages in enumerate(groups, start=1):
        payload = {**header, '_upload': {**header['_upload'], 'part': number, 'parts': len(groups)},
                   'messages': messages, 'messageCount': len(messages)}
        body = encode(payload)
        if len(body) > max_bytes:
            raise ValueError('Partition exceeds the upload size limit')
        yield body


def upload(body, endpoint, token, opener=None, pause=time.sleep):
    parsed = urllib.parse.urlsplit(endpoint)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError('Use an HTTPS Worker URL without credentials, query or fragment')
    if not token.strip():
        raise ValueError('An upload token is required; do not use a Discord account token')
    digest = hashlib.sha256(body).hexdigest()
    open_request = opener or urllib.request.build_opener(NoRedirect()).open
    for attempt in range(5):
        request = urllib.request.Request(endpoint.rstrip('/'), data=body, method='POST', headers={
            'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token.strip(), 'Idempotency-Key': digest})
        try:
            with open_request(request, timeout=90) as response:
                result = json.load(response)
            if not isinstance(result, dict) or not result.get('success') or not result.get('key') or result.get('sha256') != digest:
                raise RuntimeError('Receiver did not verify the upload checksum. Update the Worker before uploading private exports.')
            return result
        except urllib.error.HTTPError as exc:
            if exc.code not in (429, 500, 502, 503, 504):
                raise RuntimeError(f'Upload rejected: HTTP {exc.code}. Check the Worker version, binding, and upload token.') from None
            try:
                delay = float(exc.headers.get('Retry-After', min(2 ** attempt, 30)))
            except (TypeError, ValueError):
                delay = 2
            if delay > 120:
                raise RuntimeError('Upload rate-limited for more than two minutes; progress was preserved') from None
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError):
            delay = min(2 ** attempt, 30)
        if attempt < 4:
            pause(max(1, delay))
    raise RuntimeError('Upload retry limit reached; confirmed parts remain in the progress file')


def check_receiver(endpoint, token, opener=None):
    parsed = urllib.parse.urlsplit(endpoint)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError('Use an HTTPS Worker URL without credentials, query or fragment')
    if not token.strip():
        raise ValueError('An upload token is required')
    url = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, '/api/upload-status', '', ''))
    request = urllib.request.Request(url, headers={'Authorization': 'Bearer ' + token.strip()})
    open_request = opener or urllib.request.build_opener(NoRedirect()).open
    try:
        with open_request(request, timeout=30) as response:
            value = json.load(response)
        if not isinstance(value, dict) or value.get('ready') is not True or value.get('format') != 'DiscordChatExporter' or value.get('version') != 1:
            raise ValueError('Unsupported receiver')
    except Exception:
        raise RuntimeError('Receiver check failed. Deploy the updated Worker and configure UPLOAD_TOKEN before uploading. No export data was sent.') from None


class Progress:
    def __init__(self, path):
        self.path = Path(path)
        if self.path.exists():
            self.data = json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(self.data, dict) or self.data.get('format') != 'discord-export-upload-v1' or not isinstance(self.data.get('completed'), dict):
                raise ValueError('Unrecognized upload progress file; choose a different --state path')
        else:
            self.data = {'format': 'discord-export-upload-v1', 'completed': {}}

    def identifier(self, endpoint, body):
        return hashlib.sha256(endpoint.rstrip('/').encode() + b'\0' + body).hexdigest()

    def done(self, endpoint, body):
        return self.identifier(endpoint, body) in self.data['completed']

    def confirm(self, endpoint, body, result):
        self.data['completed'][self.identifier(endpoint, body)] = {'key': result['key'], 'sha256': result['sha256']}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(self.path.name + '.tmp')
        temporary.write_text(json.dumps(self.data, indent=2), encoding='utf-8')
        temporary.replace(self.path)


def upload_file(path, endpoint, token, progress, notify=print, send=upload, force=False):
    path = Path(path)
    if path.stat().st_size > MAX_FILE_BYTES:
        raise ValueError('File exceeds 64 MB; use exporter partitioning')
    raw = path.read_bytes()
    count = 0
    for number, body in enumerate(partitions(raw), start=1):
        if progress.done(endpoint, body) and not force:
            continue
        result = send(body, endpoint, token)
        progress.confirm(endpoint, body, result)
        count += 1
        notify(f'{path.name}: part {number} confirmed ({result.get("messages", "unknown")} messages)')
    return count


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('files', nargs='*')
    parser.add_argument('--folder', help='Folder containing JSON exports; subfolders are not scanned')
    parser.add_argument('--website', default='')
    parser.add_argument('--watch', action='store_true')
    parser.add_argument('--interval-seconds', type=int, default=60)
    parser.add_argument('--state', default=str(Path(os.environ.get('LOCALAPPDATA', str(Path.home() / '.local/share'))) / 'DiscordLocalBackup' / 'upload-state.json'))
    parser.add_argument('--force', action='store_true', help='Re-upload confirmed parts if remote storage was replaced')
    args = parser.parse_args()
    if args.interval_seconds < 15:
        parser.error('Use an interval of at least 15 seconds')
    endpoint = args.website or input('Cloudflare Worker HTTPS URL: ').strip()
    if not args.folder and not args.files:
        args.folder = input('Folder containing DiscordChatExporter JSON files: ').strip().strip('"')
    token = os.environ.get('DASHBOARD_UPLOAD_TOKEN') or getpass.getpass('Worker UPLOAD_TOKEN (not your Discord token): ')
    try:
        progress = Progress(args.state)
    except (ValueError, OSError) as exc:
        print(f'Could not open upload progress: {exc}')
        return 1
    try:
        while True:
            try:
                check_receiver(endpoint, token)
            except (RuntimeError, ValueError) as exc:
                print(str(exc))
                if not args.watch:
                    return 1
                time.sleep(args.interval_seconds)
                continue
            paths = sorted(Path(args.folder).glob('*.json')) if args.folder else [Path(name) for name in args.files]
            failures = 0
            if not paths:
                print('No JSON export files found; no export data was uploaded.')
                if not args.watch:
                    return 1
            for path in paths:
                if path.resolve() == progress.path.resolve():
                    continue
                try:
                    upload_file(path, endpoint, token, progress, force=args.force)
                except (ValueError, RuntimeError, OSError) as exc:
                    failures += 1
                    print(f'{path.name}: {exc}')
            print(f'Folder pass finished: {len(paths)} candidate files, {failures} failures. Confirmed parts are saved locally.')
            if not args.watch:
                return 1 if failures else 0
            time.sleep(args.interval_seconds)
    except KeyboardInterrupt:
        print('Stopped. Confirmed parts will be skipped on the next run.')
        return 130


if __name__ == '__main__':
    raise SystemExit(main())
