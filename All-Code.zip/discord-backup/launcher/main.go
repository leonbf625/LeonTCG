// A minimal console launcher with a bundled, checksum-verified official Python runtime.
package main

import (
	"archive/zip"
	"bytes"
	"crypto/sha256"
	_ "embed"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

//go:embed runtime.zip
var runtimeZip []byte

//go:embed app.zip
var appZip []byte

func unpack(data []byte, destination string) error {
	reader, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil { return err }
	for _, entry := range reader.File {
		name := filepath.FromSlash(entry.Name)
		if filepath.IsAbs(name) || strings.Contains(name, ":") || name == ".." || strings.HasPrefix(name, ".."+string(os.PathSeparator)) {
			return fmt.Errorf("unsafe bundled archive path")
		}
		path := filepath.Join(destination, name)
		if entry.FileInfo().IsDir() {
			if err := os.MkdirAll(path, 0700); err != nil { return err }
			continue
		}
		if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil { return err }
		input, err := entry.Open()
		if err != nil { return err }
		output, err := os.OpenFile(path, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
		if err != nil { input.Close(); return err }
		_, copyErr := io.Copy(output, input)
		closeErr := output.Close()
		input.Close()
		if copyErr != nil { return copyErr }
		if closeErr != nil { return closeErr }
	}
	return nil
}

func run() error {
	root, err := os.UserCacheDir()
	if err != nil { return err }
	// Use a new private session directory: do not execute stale or modified cached scripts.
	base := filepath.Join(root, "DiscordLocalBackup")
	if err := os.MkdirAll(base, 0700); err != nil { return err }
	session, err := os.MkdirTemp(base, "session-")
	if err != nil { return err }
	defer os.RemoveAll(session)
	fmt.Println("Discord Local Backup — preparing the bundled runtime…")
	if err := unpack(runtimeZip, filepath.Join(session, "runtime")); err != nil { return err }
	if err := unpack(appZip, filepath.Join(session, "app")); err != nil { return err }
	runtimeSum := sha256.Sum256(runtimeZip)
	fmt.Printf("Bundled runtime checksum: %x\n", runtimeSum)
	python := filepath.Join(session, "runtime", "python.exe")
	arguments := []string{"-I", "-u", "-X", "utf8", filepath.Join(session, "app", "web_app.py")}
	// -I isolates user site packages; explicitly launch through the bundled application path.
	// In isolated mode Python omits the script's directory from sys.path, so add only our app folder.
	bootstrap := "import runpy,sys; p=sys.argv.pop(1); sys.path.insert(0,p); runpy.run_path(p+'/web_app.py',run_name='__main__')"
	arguments = []string{"-I", "-u", "-X", "utf8", "-c", bootstrap, filepath.Join(session, "app")}
	arguments = append(arguments, os.Args[1:]...)
	command := exec.Command(python, arguments...)
	command.Dir = filepath.Join(session, "app")
	command.Stdin, command.Stdout, command.Stderr = os.Stdin, os.Stdout, os.Stderr
	return command.Run()
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "Could not start Discord Local Backup:", err)
		fmt.Fprintln(os.Stderr, "Press Enter to close. Copy the error above; do not share any credentials.")
		var line string
		fmt.Scanln(&line)
		os.Exit(1)
	}
}
