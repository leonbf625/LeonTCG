module local/discord-backup-launcher

go 1.26
