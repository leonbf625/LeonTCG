package main

import (
	"archive/zip"
	"bytes"
	"os"
	"path/filepath"
	"testing"
)

func testZip(name, content string) []byte {
	var buffer bytes.Buffer
	writer := zip.NewWriter(&buffer)
	file, _ := writer.Create(name)
	file.Write([]byte(content))
	writer.Close()
	return buffer.Bytes()
}

func TestUnpack(t *testing.T) {
	directory := t.TempDir()
	if err := unpack(testZip("nested/test.txt", "hello"), directory); err != nil { t.Fatal(err) }
	data, err := os.ReadFile(filepath.Join(directory, "nested", "test.txt"))
	if err != nil || string(data) != "hello" { t.Fatalf("unexpected output: %q, %v", data, err) }
}

func TestRejectTraversal(t *testing.T) {
	for _, path := range []string{"../outside.txt", "/absolute.txt", "C:/absolute.txt"} {
		if err := unpack(testZip(path, "bad"), t.TempDir()); err == nil { t.Errorf("accepted %s", path) }
	}
}
