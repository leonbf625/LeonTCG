"""Prepare sanitized public source and Windows bundles. Does not upload or deploy."""
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
OUT = WORKSPACE / 'combined-download'
SKIP = {'node_modules', '.venv', '__pycache__', '.wrangler', '.git', 'artifacts'}
SUFFIXES = {'.py', '.go', '.mod', '.json', '.jsonc', '.html', '.css', '.js', '.mjs', '.ps1', '.cmd', '.md', '.txt'}


def sanitize(data):
    for original, replacement in [(b'you@example.com', b'you@example.com'),
                                  (b'your-worker.workers.dev', b'your-worker.workers.dev'),
                                  (b'your-export-receiver', b'your-export-receiver')]:
        data = data.replace(original, replacement)
    return data


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    OUT.mkdir(exist_ok=True)
    contents = {}
    for name in ('discord-backup', 'pokemon-tracker'):
        for current, dirs, files in os.walk(WORKSPACE / name):
            dirs[:] = sorted(value for value in dirs if value not in SKIP)
            for filename in sorted(files):
                path = Path(current) / filename
                if filename.startswith(('.env', '.dev.vars')) or (path.suffix not in SUFFIXES and filename != '.gitignore'):
                    continue
                if path.is_symlink():
                    raise ValueError('Unexpected source symlink')
                contents[path.relative_to(WORKSPACE).as_posix()] = sanitize(path.read_bytes())
    manifest = [{'path': name, 'bytes': len(data), 'sha256': digest(data)} for name, data in contents.items()]
    contents['MANIFEST.json'] = json.dumps(manifest, indent=2).encode()
    contents['notes/DeepSeek-Development-Logs.md'] = sanitize((ROOT / 'artifacts/DeepSeek-Development-Logs.md').read_bytes())
    readme = '''# Discord backup — combined code and Windows test build

All source, tests and documentation are in discord-backup/ and pokemon-tracker/.
The latter is the earlier card-bot prototype, superseded by the backup application.
MANIFEST.json verifies source-file hashes. Credentials, real Discord messages,
backup databases, installed dependencies and compiler caches are excluded.
Personal service/account defaults have been replaced with public placeholders.

For the Windows test bundle, Extract All and run Windows/DiscordLocalBackup-Windows-x64.exe.
It is an unsigned Windows 10/11 x64 test build with a bundled official Python runtime.
It has not been executed on Windows in this environment. Use Windows/Upload Exports.cmd
to upload existing DiscordChatExporter JSON; use --watch from PowerShell to watch a folder.

Cloudflare-Receiver.js is a complete single-file Worker with the private website
embedded. It can replace the supplied POST-only receiver while reusing EXPORTS.
Configure DASHBOARD_EMAIL, DASHBOARD_PASSWORD and UPLOAD_TOKEN securely in Cloudflare.
Read discord-backup/website/EXISTING_WORKER.md before deploying. No live deployment
or authenticated Discord test has been performed. The uploader performs a readiness
check and checksum confirmation; it never needs a Discord token.

See discord-backup/TEST_RESULTS.md for exact validation evidence and limitations.
To rebuild the EXE, prepare the verified upstream runtime ZIP identified by
runtime-provenance.json and use build_windows.py with an official Go compiler.
The source-only ZIP does not include the EXE or upstream runtime binaries.
'''
    contents['README.md'] = readme.encode()
    worker = sanitize((ROOT / 'artifacts/Cloudflare-Receiver.js').read_bytes())
    contents['Cloudflare-Receiver.js'] = worker
    (OUT / 'Cloudflare-Receiver.js').write_bytes(worker)
    source_zip = OUT / 'All-Code.zip'
    with zipfile.ZipFile(source_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in contents.items():
            archive.writestr(name, data)
    app_zip = ROOT / 'launcher/app.zip'
    original = app_zip.read_bytes()
    exe = OUT / 'DiscordLocalBackup-Windows-x64.exe'
    try:
        with zipfile.ZipFile(io.BytesIO(original)) as previous, zipfile.ZipFile(app_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as updated:
            for item in previous.infolist():
                updated.writestr(item, sanitize(previous.read(item.filename)))
        env = dict(os.environ, GOOS='windows', GOARCH='amd64', CGO_ENABLED='0', GOTOOLCHAIN='local')
        subprocess.run([os.environ.get('GO_BIN', 'go'), 'build', '-trimpath', '-buildvcs=false', '-ldflags=-s -w -buildid=', '-o', str(exe), '.'], cwd=ROOT / 'launcher', env=env, check=True)
    finally:
        app_zip.write_bytes(original)
    combined = OUT / 'All-Code-and-Windows-Test.zip'
    with zipfile.ZipFile(combined, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in contents.items():
            archive.writestr(name, data)
        archive.write(exe, 'Windows/DiscordLocalBackup-Windows-x64.exe')
        archive.write(ROOT / 'Upload Exports.cmd', 'Windows/Upload Exports.cmd')
        archive.write(ROOT / 'THIRD_PARTY_NOTICES.txt', 'Windows/THIRD_PARTY_NOTICES.txt')
        archive.writestr('Windows/SHA256SUMS.txt', digest(exe.read_bytes()) + '  DiscordLocalBackup-Windows-x64.exe\n')
    for path in (source_zip, combined):
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            for entry in manifest:
                assert digest(archive.read(entry['path'])) == entry['sha256']
            for name in archive.namelist():
                if not name.endswith('.exe'):
                    assert b'you@example.com' not in archive.read(name)
    (OUT / 'SHA256SUMS.txt').write_text(digest(source_zip.read_bytes()) + '  All-Code.zip\n')
    (OUT / 'BUNDLE-SHA256SUMS.txt').write_text(digest(combined.read_bytes()) + '  All-Code-and-Windows-Test.zip\n')
    print(f'Verified {len(manifest)} source/documentation files, source ZIP, standalone Worker, and combined Windows ZIP.')
    print('Combined bundle:', combined.stat().st_size, 'bytes; SHA-256', digest(combined.read_bytes()))


if __name__ == '__main__':
    main()
