@echo off
setlocal
cd /d "%~dp0"
if exist "DiscordLocalBackup-Windows-x64.exe" (
  "DiscordLocalBackup-Windows-x64.exe" --upload-exports %*
) else (
  py -3 upload_exports.py %*
)
set "upload_exit=%errorlevel%"
pause
exit /b %upload_exit%
