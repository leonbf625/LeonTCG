"""Windows-friendly desktop interface; all network work runs off the UI thread."""
import json
import os
from pathlib import Path
import queue
import sqlite3
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from backup import Archive, DiscordAPI, Stopped, discover, run_backup
from monitor import cycle
from sync import publish


class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Discord Local Backup")
        self.root.geometry("1160x900")
        self.events = queue.Queue()
        self.stop = threading.Event()
        self.worker = None
        self.channels = []
        self.token = tk.StringVar()
        self.output = tk.StringVar(value=str(Path.home() / "Documents" / "DiscordBackup"))
        self.bot = tk.BooleanVar(value=False)
        self.media = tk.BooleanVar(value=True)
        self.search_text = tk.StringVar()
        self.account_text = tk.StringVar(value="Account: not connected")
        self.coverage_text = tk.StringVar(value="No channel coverage loaded")
        self.filter = tk.StringVar(value="All")
        self.website = tk.StringVar()
        self.upload_token = tk.StringVar()
        self.auto = tk.BooleanVar(value=False)
        self.interval = tk.StringVar(value="15")
        frame = ttk.Frame(root, padding=14)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Discord Local Backup", font=("Segoe UI", 19, "bold")).pack(anchor="w")
        ttk.Label(frame, text="Local backup of channels you can access. No password collection or account-token extraction.").pack(anchor="w", pady=(3, 10))
        ttk.Label(frame, text="Token (held in memory; never written to settings or logs)").pack(anchor="w")
        self.token_entry = ttk.Entry(frame, textvariable=self.token, show="•")
        self.token_entry.pack(fill="x")
        ttk.Checkbutton(frame, text="This is a bot token", variable=self.bot).pack(anchor="w")
        ttk.Label(frame, textvariable=self.account_text).pack(anchor="w")
        row = ttk.Frame(frame)
        row.pack(fill="x", pady=8)
        ttk.Label(row, text="Backup folder:").pack(side="left")
        ttk.Entry(row, textvariable=self.output).pack(side="left", fill="x", expand=True, padx=8)
        ttk.Button(row, text="Browse", command=self.browse).pack(side="left")
        ttk.Checkbutton(frame, text="Download attachments (may use substantial disk space)", variable=self.media).pack(anchor="w")
        row = ttk.Frame(frame)
        row.pack(fill="x", pady=4)
        ttk.Checkbutton(row, text="Auto scan selected channels every", variable=self.auto).pack(side="left")
        ttk.Spinbox(row, from_=5, to=1440, textvariable=self.interval, width=5).pack(side="left", padx=5)
        ttk.Label(row, text="minutes (while this app stays open)").pack(side="left")
        row = ttk.Frame(frame)
        row.pack(fill="x", pady=4)
        ttk.Label(row, text="Private website URL (optional):").pack(side="left")
        ttk.Entry(row, textvariable=self.website).pack(side="left", fill="x", expand=True, padx=5)
        ttk.Label(row, text="Upload token:").pack(side="left")
        ttk.Entry(row, textvariable=self.upload_token, show="•", width=25).pack(side="left")
        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", pady=8)
        self.discover_button = ttk.Button(buttons, text="1. Find server channels", command=self.discover)
        self.discover_button.pack(side="left")
        self.backup_button = ttk.Button(buttons, text="2. Back up selected", command=self.backup)
        self.backup_button.pack(side="left", padx=8)
        ttk.Button(buttons, text="Select visible", command=lambda: self.channel_list.selection_set(self.channel_list.get_children())).pack(side="left")
        ttk.Button(buttons, text="Refresh coverage", command=self.load_coverage).pack(side="left", padx=5)
        ttk.Button(buttons, text="Stop safely", command=self.stop.set).pack(side="right")
        ttk.Label(frame, text="Select channels below (Ctrl/Shift for multiple). Forbidden channels are reported, never bypassed.").pack(anchor="w")
        row = ttk.Frame(frame)
        row.pack(fill="x")
        ttk.Label(row, textvariable=self.coverage_text).pack(side="left")
        dropdown = ttk.Combobox(row, textvariable=self.filter, values=["All", "Unchecked", "Checked", "Failed"], state="readonly", width=12)
        dropdown.pack(side="right")
        dropdown.bind("<<ComboboxSelected>>", lambda _: self.render_channels())
        list_frame = ttk.Frame(frame)
        list_frame.pack(fill="both", expand=True)
        columns = ("server", "channel", "checked", "status", "last_checked", "messages")
        self.channel_list = ttk.Treeview(list_frame, columns=columns, show="headings", selectmode="extended", height=10)
        for name, label, width in [("server", "Server", 180), ("channel", "Channel", 190), ("checked", "Checked?", 75), ("status", "Result", 150), ("last_checked", "Last checked (UTC)", 185), ("messages", "Saved", 65)]:
            self.channel_list.heading(name, text=label)
            self.channel_list.column(name, width=width, minwidth=55)
        self.channel_list.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.channel_list.yview)
        scroll.pack(side="right", fill="y")
        self.channel_list.configure(yscrollcommand=scroll.set)
        row = ttk.Frame(frame)
        row.pack(fill="x", pady=8)
        ttk.Entry(row, textvariable=self.search_text).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Search local backup", command=self.search).pack(side="left", padx=8)
        ttk.Button(row, text="Open folder", command=self.open_folder).pack(side="left")
        self.status = tk.StringVar(value="Ready. A user token uses an unsupported Discord route and may risk account suspension.")
        ttk.Label(frame, textvariable=self.status, wraplength=920).pack(anchor="w", pady=4)
        self.log = tk.Text(frame, height=9, state="disabled", wrap="word")
        self.log.pack(fill="both", expand=True)
        root.after(100, self.poll)
        root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(200, self.load_coverage)

    def browse(self):
        if not self.busy():
            selected = filedialog.askdirectory()
            if selected:
                self.output.set(selected)
                self.load_coverage()

    def load_coverage(self):
        if self.busy():
            return
        path = Path(self.output.get()) / "archive.sqlite3"
        if not path.exists():
            self.channels = []
            self.render_channels()
            self.account_text.set("Account: not connected")
            return
        try:
            archive = Archive(self.output.get())
            try:
                self.show_report(archive.report())
            finally:
                archive.close()
        except Exception as exc:
            self.status.set(f"Cannot load coverage: {exc}")

    def show_report(self, report):
        self.channels = report.get("channels", [])
        account = report.get("account")
        if account:
            self.account_text.set(f"Discord account: {account.get('username', 'unknown')} — ID {account['id']}")
        coverage = report.get("coverage", {})
        self.coverage_text.set(f"Discovered: {coverage.get('discovered', 0)} | Checked: {coverage.get('checked', 0)} | Unchecked: {coverage.get('unchecked', 0)} | Failed: {coverage.get('failed', 0)}")
        self.render_channels()

    def render_channels(self):
        selected = set(self.channel_list.selection())
        self.channel_list.delete(*self.channel_list.get_children())
        for item in self.channels:
            checked = bool(item.get("last_checked_at"))
            if self.filter.get() == "Unchecked" and checked:
                continue
            if self.filter.get() == "Checked" and not checked:
                continue
            if self.filter.get() == "Failed" and item.get("status") != "failed":
                continue
            self.channel_list.insert("", "end", iid=item["id"], values=(
                item.get("guild") or "Unknown", item.get("channel", item["id"]),
                "Yes" if checked else "No", item.get("status", "not started"),
                item.get("last_checked_at") or "Never", item.get("messages", 0)))
        self.channel_list.selection_set([cid for cid in selected if self.channel_list.exists(cid)])

    def busy(self):
        return self.worker is not None and self.worker.is_alive()

    def launch(self, operation):
        if self.busy():
            messagebox.showinfo("Backup running", "Wait for the current operation or use Stop safely.")
            return
        token = self.token.get().strip()
        if not token:
            messagebox.showerror("Token needed", "Supply a Discord token locally. Do not share it in chat.")
            return
        if not self.output.get().strip():
            messagebox.showerror("Folder needed", "Choose a backup folder.")
            return
        folder, bot, media = self.output.get(), self.bot.get(), self.media.get()
        self.stop.clear()
        self.status.set("Working… you can stop safely between requests.")
        self.discover_button.configure(state="disabled")
        self.backup_button.configure(state="disabled")
        def work():
            archive = None
            try:
                archive = Archive(folder)
                api = DiscordAPI(token, bot=bot, stop=self.stop)
                account = api.get("/users/@me")
                archive.bind_account(account)
                self.events.put(("report", archive.report()))
                operation(api, archive, media)
            except Stopped:
                self.events.put(("log", "Paused. Restart the same backup to resume committed pages."))
            except Exception as exc:
                self.events.put(("log", f"Operation failed: {exc}"))
            finally:
                try:
                    if archive:
                        self.events.put(("report", archive.report()))
                except Exception as exc:
                    self.events.put(("log", f"Could not save coverage report: {type(exc).__name__}"))
                finally:
                    if archive:
                        archive.close()
                    self.events.put(("done", None))
        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def discover(self):
        def operation(api, archive, media):
            channels = discover(api, archive, lambda text: self.events.put(("log", text)))
            self.events.put(("report", archive.report()))
            self.events.put(("log", f"Found {len(channels)} candidate channels. Discovery errors are in report.json."))
        self.launch(operation)

    def backup(self):
        selected = set(self.channel_list.selection())
        channels = [{"id": item["id"], "name": item["channel"], "guild_id": item.get("guild_id"), "guild_name": item.get("guild")} for item in self.channels if item["id"] in selected]
        if not channels:
            messagebox.showinfo("Select channels", "Find channels, then select the ones to archive.")
            return
        auto, website, upload_token = self.auto.get(), self.website.get().strip(), self.upload_token.get()
        try:
            minutes = int(self.interval.get())
            if minutes < 5:
                raise ValueError()
        except ValueError:
            messagebox.showerror("Scan interval", "Choose an interval of at least five minutes.")
            return
        def operation(api, archive, media):
            notify = lambda text: self.events.put(("log", text))
            while True:
                try:
                    if auto:
                        failures = cycle(api, archive, selected, media, website, upload_token, notify)
                    else:
                        failures = run_backup(api, archive, channels, media, notify)
                        if website:
                            publish(archive, website, upload_token)
                            notify("Private website updated.")
                    notify(f"Run ended: {failures} failed operations. Review report.json for coverage.")
                except Stopped:
                    raise
                except Exception as exc:
                    notify(f"Scan/sync failed: {exc}")
                    if not auto:
                        raise
                self.events.put(("report", archive.report()))
                if not auto:
                    break
                notify(f"Next scan in {minutes} minutes. Use Stop safely to end automatic scans.")
                if api.stop.wait(minutes * 60):
                    raise Stopped()
        self.launch(operation)

    def poll(self):
        try:
            # Bound work per tick so large logs do not freeze the interface.
            for _ in range(100):
                kind, value = self.events.get_nowait()
                if kind == "log":
                    self.log.configure(state="normal")
                    self.log.insert("end", value + "\n")
                    if int(self.log.index("end-1c").split(".")[0]) > 1500:
                        self.log.delete("1.0", "300.0")
                    self.log.see("end")
                    self.log.configure(state="disabled")
                elif kind == "report":
                    self.show_report(value)
                elif kind == "done":
                    self.status.set("Operation stopped or finished. Check the log and report.json for results.")
                    self.discover_button.configure(state="normal")
                    self.backup_button.configure(state="normal")
        except queue.Empty:
            pass
        self.root.after(100, self.poll)

    def search(self):
        if self.busy():
            messagebox.showinfo("Backup running", "Pause or finish the backup before searching.")
            return
        path = Path(self.output.get()) / "archive.sqlite3"
        if not path.is_file():
            messagebox.showinfo("No backup", "Run a backup first, or choose an existing backup folder.")
            return
        term = self.search_text.get().strip()
        try:
            with sqlite3.connect(path) as db:
                db.execute("PRAGMA query_only=ON")
                rows = db.execute('''SELECT c.guild_name,c.name,m.timestamp,m.author,m.content
                    FROM messages m LEFT JOIN channels c ON c.id=m.channel_id
                    WHERE instr(lower(m.content),lower(?)) > 0
                    ORDER BY m.timestamp DESC LIMIT 200''', (term,)).fetchall()
            window = tk.Toplevel(self.root)
            window.title("Local search — up to 200 most recent matches")
            window.geometry("900x600")
            text = tk.Text(window, wrap="word")
            text.pack(fill="both", expand=True)
            for guild, channel, timestamp, author, content in rows:
                text.insert("end", f"{guild or ''} / {channel} | {timestamp} | {author}\n{content}\n\n")
            if not rows:
                text.insert("end", "No matching messages.")
            text.configure(state="disabled")
        except sqlite3.Error as exc:
            messagebox.showerror("Search failed", str(exc))

    def open_folder(self):
        path = Path(self.output.get())
        if os.name == "nt" and path.is_dir():
            os.startfile(path)
        else:
            messagebox.showinfo("Backup folder", str(path.resolve()))

    def close(self):
        if self.busy():
            self.stop.set()
            self.status.set("Stopping safely. Please wait for the current request to finish, then close again.")
            return
        self.token.set("")
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
