"""Local browser interface. Credentials are accepted only on an authenticated loopback session."""
from __future__ import annotations

import argparse
from collections import deque
from datetime import datetime, timedelta, timezone
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import secrets
import threading
import urllib.parse
import webbrowser

from backup import Archive, DiscordAPI, Stopped
from monitor import cycle
from backup import discover
from sync import snapshot
from prompt_export import create_prompt

ASSETS = Path(__file__).parent / "website" / "public"


class State:
    def __init__(self, folder=None):
        self.key = secrets.token_urlsafe(32)
        self.folder = str(folder or Path.home() / "Documents" / "DiscordBackup")
        self.config = {}
        self.logs = deque(maxlen=500)
        self.stop = threading.Event()
        self.lock = threading.Lock()
        self.busy = False
        self.status = "Idle"
        self.next_scan = None
        self.thread = None

    def log(self, message):
        now = datetime.now().astimezone().strftime("%H:%M:%S")
        with self.lock:
            self.logs.append(f"{now}  {message}")

    def public(self):
        with self.lock:
            return {"busy": self.busy, "status": self.status, "next_scan": self.next_scan,
                    "credential_held": bool(self.config.get("token")), "logs": list(self.logs)}

    def read_report(self):
        value = {"account": None, "channels": [], "recent_messages": []}
        path = Path(self.folder) / "dashboard-local.json"
        if path.exists():
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                pass
        report = Path(self.folder) / "report.json"
        if report.exists():
            try:
                latest = json.loads(report.read_text(encoding="utf-8"))
                latest["recent_messages"] = value.get("recent_messages", [])
                return latest
            except (OSError, ValueError):
                pass
        return value

    def save_report(self, archive):
        destination = archive.folder / "dashboard-local.json"
        temporary = destination.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(snapshot(archive), ensure_ascii=False), encoding="utf-8")
        temporary.replace(destination)

    def start(self, values, discovery=False):
        if not isinstance(values, dict):
            raise ValueError("Expected an object")
        with self.lock:
            if self.busy:
                raise ValueError("A scan is running. Stop it before changing settings.")
            config = dict(self.config)
            # A blank field reuses the credential already held in memory.
            for key in ("token", "upload_token"):
                if values.get(key):
                    if not isinstance(values[key], str) or len(values[key]) > 4096:
                        raise ValueError("Invalid credential")
                    config[key] = values[key].strip()
            if not config.get("token"):
                raise ValueError("Enter a Discord token locally to connect")
            folder = values.get("folder", self.folder)
            if not isinstance(folder, str) or not folder.strip():
                raise ValueError("Choose a backup folder")
            config["folder"] = str(Path(folder).expanduser().resolve())
            try:
                config["interval"] = int(values.get("interval", 15))
            except (ValueError, TypeError):
                raise ValueError("Interval must be a whole number") from None
            if not 5 <= config["interval"] <= 1440:
                raise ValueError("Choose an interval from 5 to 1440 minutes")
            for key, default in (("bot", False), ("attachments", True), ("auto", True), ("all_channels", False)):
                config[key] = bool(values.get(key, default))
            selected = values.get("selected", [])
            if not isinstance(selected, list) or len(selected) > 10000 or any(not isinstance(cid, str) or not cid.isdigit() for cid in selected):
                raise ValueError("Invalid channel selection")
            config["selected"] = set(selected)
            config["website"] = str(values.get("website", "")).strip()
            if config["website"]:
                url = urllib.parse.urlsplit(config["website"])
                if url.scheme != "https" or not url.hostname or url.username or url.query or url.fragment:
                    raise ValueError("Website must be an HTTPS URL without credentials or query parameters")
                if not config.get("upload_token"):
                    raise ValueError("Supply a separate website upload token")
            if not discovery and not config["all_channels"] and not selected:
                raise ValueError("Select channels or enable All discovered channels")
            self.config = config
            self.folder = config["folder"]
            self.stop.clear()
            self.busy = True
            self.status = "Discovering channels" if discovery else "Scanning"
            self.next_scan = None
            self.thread = threading.Thread(target=self.work, args=(config, discovery), daemon=True)
            self.thread.start()

    def work(self, config, discovery):
        archive = None
        api = DiscordAPI(config["token"], bot=config["bot"], stop=self.stop)
        try:
            archive = Archive(config["folder"])
            while not self.stop.is_set():
                try:
                    with self.lock:
                        self.status = "Discovering channels" if discovery else "Scanning"
                        self.next_scan = None
                    if discovery:
                        account = api.get("/users/@me")
                        archive.bind_account(account)
                        self.log(f"Connected to {account.get('username', 'unknown')} (ID {account['id']})")
                        self.save_report(archive)
                        channels = discover(api, archive, self.log)
                        self.log(f"Found {len(channels)} candidate channels. Review discovery errors in report.json.")
                    else:
                        selection = None if config["all_channels"] else config["selected"]
                        failures = cycle(api, archive, selection, config["attachments"], config["website"], config.get("upload_token", ""), self.log)
                        self.log(f"Scan finished with {failures} failed channel/attachment operations.")
                    self.save_report(archive)
                except Stopped:
                    raise
                except Exception as exc:
                    self.log(f"Scan failed: {exc}")
                    if archive:
                        self.save_report(archive)
                if discovery or not config["auto"]:
                    break
                with self.lock:
                    self.status = "Waiting for next scan"
                    self.next_scan = (datetime.now(timezone.utc) + timedelta(minutes=config["interval"])).isoformat(timespec="seconds")
                self.log(f"Next scan in {config['interval']} minutes. Keep this app open.")
                if self.stop.wait(config["interval"] * 60):
                    break
        except Stopped:
            self.log("Stopped safely; committed message pages will resume on the next scan.")
        except Exception as exc:
            self.log(f"Scanner stopped: {type(exc).__name__}: {exc}")
        finally:
            try:
                if archive:
                    try:
                        self.save_report(archive)
                    finally:
                        archive.close()
            except Exception as exc:
                self.log(f"Could not save final report: {type(exc).__name__}")
            with self.lock:
                self.busy = False
                self.status = "Stopped" if self.stop.is_set() else "Idle — review logs for results"
                self.next_scan = None


def make_handler(state):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            # HTTP logging is disabled so credentials/URLs cannot enter request logs.
            pass

        def reply(self, value, status=200):
            self.send_bytes(json.dumps(value, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8", status)

        def send_bytes(self, data, content_type, status=200):
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            self.end_headers()
            self.wfile.write(data)

        def authorized(self):
            # Check both session key and Host, including DNS-rebinding protection.
            return self.headers.get("Host") == f"127.0.0.1:{self.server.server_port}" and hmac.compare_digest(self.headers.get("X-Local-Key", ""), state.key)

        def do_GET(self):
            path = urllib.parse.urlsplit(self.path).path
            if path.startswith("/api/"):
                if not self.authorized():
                    self.reply({"error": "Local session expired or unauthorized. Reopen the URL shown in the app console."}, 401)
                    return
                if path == "/api/mode":
                    self.reply({"local": True, "default_folder": state.folder})
                elif path == "/api/report":
                    self.reply(state.read_report())
                elif path == "/api/state":
                    self.reply(state.public())
                else:
                    self.reply({"error": "Not found"}, 404)
                return
            assets = {"/": ("index.html", "text/html; charset=utf-8"), "/app.js": ("app.js", "text/javascript; charset=utf-8"), "/style.css": ("style.css", "text/css; charset=utf-8")}
            if path not in assets:
                self.reply({"error": "Not found"}, 404)
                return
            filename, mime = assets[path]
            self.send_bytes((ASSETS / filename).read_bytes(), mime)

        def do_POST(self):
            expected_origin = f"http://127.0.0.1:{self.server.server_port}"
            if not self.authorized() or self.headers.get("Origin") not in (None, expected_origin):
                self.reply({"error": "Unauthorized local request"}, 401)
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 100000:
                    self.reply({"error": "Invalid request size"}, 413)
                    return
                values = json.loads(self.rfile.read(length))
                if self.path == "/api/export-prompt":
                    if not isinstance(values, dict):
                        raise ValueError("Expected an object")
                    selected = values.get("selected", [])
                    if not isinstance(selected, list) or any(not isinstance(value, str) or not value.isdigit() for value in selected):
                        raise ValueError("Invalid channel selection")
                    path, text = create_prompt(state.folder, state.public()["logs"], bool(values.get("include_messages")), selected,
                                               (state.config.get("token", ""), state.config.get("upload_token", "")), values.get("goal"))
                    self.send_bytes(text.encode("utf-8"), "text/markdown; charset=utf-8")
                    state.log(f"DeepSeek prompt exported locally to {path.name}. No AI service was contacted.")
                    return
                elif self.path == "/api/stop":
                    state.stop.set()
                    state.log("Stop requested; waiting for the current request to finish.")
                elif self.path in ("/api/start", "/api/discover"):
                    state.start(values, discovery=self.path == "/api/discover")
                else:
                    self.reply({"error": "Not found"}, 404)
                    return
                self.reply({"ok": True})
            except (ValueError, TypeError, OSError) as exc:
                self.reply({"error": str(exc)}, 400)

    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--port", type=int, default=0)
    args = parser.parse_args()
    state = State()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(state))
    url = f"http://127.0.0.1:{server.server_port}/#key={state.key}"
    print("Discord Local Backup — keep this window open while scanning.")
    print("Local interface:", url, flush=True)
    print("Your Discord credentials stay in memory on this computer. Ctrl+C stops the app.")
    if not args.no_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        state.stop.set()
        if state.thread:
            state.thread.join(timeout=65)
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
