# Discord Local Backup for Windows

A local Windows application for backing up message history from Discord server
channels your credentials can read. The portable EXE bundles Python and opens a
local browser interface. It includes automatic scans, account identity, channel
coverage, checked/unchecked filters, timestamps, logs, recent-message search, and
optional private website sync. It also has a separate Python command-line interface.
The EXE is an unsigned Windows x64 test build, not a signed installer.

## Portable Windows EXE

Run `DiscordLocalBackup-Windows-x64.exe` on Windows 10/11 x64. No Python installation
is needed for the EXE. It extracts its bundled official runtime into a temporary
session directory under your local app-data cache, opens your default browser,
and keeps the console open for errors. Keep the EXE console running while scans
are active. Closing only the browser tab does not stop the scanner. Use **Stop
safely**, then Ctrl+C in the console to exit. Antivirus/SmartScreen may flag an
unrecognized unsigned build; review its source and checksum before deciding
whether to run it. This build has not been executed on Windows in this environment.

The interface address contains a temporary local session key; do not share that
address. If you close the browser tab, reopen the address printed in the console.
The app listens only on `127.0.0.1` and protects API requests with that key. Tokens
stay in memory until the process closes. The official runtime, Python license,
and app source are bundled; there is no runtime downloader or Python installer.

## Start on Windows

For the source version only:

1. Install **Python 3.11 or newer** from https://www.python.org/downloads/windows/ .
   Include Tcl/Tk and the Python launcher (standard installer options).
2. Extract this entire ZIP to a folder you control.
3. Double-click **Start Backup.cmd**. Its console stays open if the app crashes.
4. Enter your token locally; use the bot checkbox only for a bot token. The app
   never asks for your password, extracts a token, or saves it to settings/logs.
5. Choose a backup folder, click **Find channels**, check channels or enable **All
   discovered channels**, and click **Start backup**. **Select visible** selects
   channels matching the current filter. Discovery may take time on large accounts.
6. Review **report.json** afterward. A channel appearing in the list does not
   prove that message history is readable. Permission errors are reported.

The application does not provide Discord OAuth login. Discord's official OAuth
login does not grant access to your personal channel history. User-token
collection uses an unsupported API route and Discord warns that automating a
personal account can result in suspension. Authorized bot access is supported,
but requires server installation and appropriate View Channel / Read Message
History permissions. Bots may also require the Message Content intent enabled
and approved by Discord; otherwise content can be empty. Do not share tokens
with websites, support chats, screenshots, or issue reports. Only use credentials
and channels you are authorized to access.

## Resume and reliability

Run again with the **same backup folder**. Completed message pages and their
resume cursor are committed in the same SQLite transaction. An interrupted
channel continues backward from its last saved page. After that completes, run
again to collect messages that arrived while the interrupted run was in progress.
Completed channels fetch messages newer than their last completed high-water
mark. Duplicate messages are keyed by channel and message ID.

**Stop safely** finishes or interrupts the current request, keeps committed work,
and returns control. Network requests have timeouts, bounded retries and rate
limit delays. Each failed channel is recorded and the next channel continues.
Attachments use temporary files followed by atomic renaming; unfinished files
are retried on the next run. A full disk or inaccessible backup folder can still
stop the application. Keep free space available and only run one instance per
backup folder. Reuse a folder for the same account only.

The backup is append-oriented: old messages are retained if deleted remotely.
Edits to messages older than the completed high-water mark are **not** refreshed.
For a fresh historical snapshot, choose a new folder. New messages arriving
during any one run may only appear on the next run.

## Backup contents

- `archive.sqlite3`: local searchable database, message JSON, progress, and errors.
- `exports/<channel-id>.jsonl`: one Discord message object per line, oldest first.
  Regenerated after each successful channel backup; the database is authoritative
  if an export is interrupted. This is JSON Lines, not a single JSON array.
- `attachments/<channel-id>/<attachment-id>_<name>`: downloaded message attachments.
- `report.json`: per-channel status and counts, attachment failures, and recent
  discovery errors. `history backed up` means the history endpoint was exhausted
  for that run, not independently proven completeness or successful attachments.

The browser interface searches the most recent 200 archived messages without a
network connection. The optional legacy Tk interface (`py -3 app.py`) provides a
full-database local search with up to 200 matches. The database and JSONL retain
all saved messages. Neither interface renders message HTML or automatically opens
attachments.

## Account and channel coverage

The connected Discord username and exact account ID appear in the interface.
Each backup folder is bound to one account; using another account requires a
different folder. Server names/IDs, channel names/IDs, last-started timestamps,
last-checked timestamps, last-success timestamps, and errors are saved in
`report.json` and `coverage.csv`. A channel is **unchecked** until a history
attempt ends. Failed/paused attempts count as **checked**, so always inspect the
result as well. History completion and attachment completion are separate.
Known channels remain in coverage if they disappear from later discovery; their
old check times are preserved. The report is not proof they remain accessible.

## Automatic scans and website sync

Enable **Auto scan**, choose an interval (minimum five minutes; default 15), and
start a backup. Runs never overlap. The app re-discovers channels every cycle;
**All discovered channels** includes newly found candidates. Otherwise only the
selected channel IDs are backed up. Keep the PC awake and the EXE running.

The private Cloudflare website is in [`website/`](website/README.md). Deployment
requires your Cloudflare login on your own machine. The included deployment
script opens the official Cloudflare login flow. The default dashboard username
is `you@example.com`; choose a separate dashboard password and upload
token. This does not sign in to that mailbox or your Discord account.

After deployment, enter its HTTPS URL and separate upload token in the local app.
Each completed scan uploads channel coverage and up to 200 recent message texts.
Full history, attachments, Discord tokens, and detailed local error logs are not
uploaded. The website is a private overview, not a replacement for the local backup.

## Export a prompt for DeepSeek

Click **Export DeepSeek prompt** under Scanner activity. It exports channel
coverage, check timestamps, failures, and recent scanner logs as a local Markdown
file. If channels are selected, the channel coverage/message excerpts are scoped
to them; recent scanner events remain account-wide. With nothing selected, all
known channels are eligible. Enable **Include message excerpts** to include up
to 100 recent archived messages, with text limited to 1,400 characters each.
The export caps channel rows at 500 and discloses its limits in the prompt.

The browser downloads the file and a copy is saved in the backup folder's
`prompts/` directory. No request is made to DeepSeek or another AI service. Known
in-memory credentials, common token patterns, and email addresses are redacted.
Automatic redaction is incomplete: review the file for private details and other
secrets before uploading it to an external provider. Quoted messages are
explicitly identified as untrusted data in the generated prompt.

Close the app before copying the backup folder to another disk. While it is
running, SQLite may have `archive.sqlite3-wal` and `archive.sqlite3-shm` files:
copying only the main database can miss recent commits. Protect backups like
private communications. Raw message payloads contain identities and may contain
signed attachment URLs. Use Windows disk encryption and restrict folder access.

## Coverage and limits

Discovery includes server text/announcement channels, message-capable voice/stage
channels, active threads, and archived public/private threads exposed by the API.
Forums and media channels are represented by their threads. Unsupported endpoints,
missing permissions and partial thread discovery are logged. DMs are not discovered
automatically; an explicit accessible DM channel ID may be supplied through the CLI.
Hidden channels, deleted messages, expired attachments, external embed images,
and history no longer available to the credentials cannot be recovered. Attachment
URLs can expire; failures remain visible. No promise of full account backup or
evidence-grade integrity is made. No posting, joining servers/threads, deleting
messages, or changing server permissions is performed.

If a run returns messages with missing content, verify permissions and bot Message
Content intent. The tool cannot independently distinguish legitimate empty/system
messages from API-redacted content. Discovery errors remain in the event history
after later success; use timestamps to identify the relevant run.

## Command-line fallback

Open PowerShell in this folder:

```powershell
py -3 backup.py --list --output "$env:USERPROFILE\Documents\DiscordBackup"
py -3 backup.py --output "$env:USERPROFILE\Documents\DiscordBackup"
py -3 backup.py --channels 123456789012345678 --no-attachments
```

The CLI prompts for a hidden token. Do not pass tokens as command-line arguments.
An optional `DISCORD_BACKUP_TOKEN` process environment binding is also supported.
Add `--bot` for bot credentials. `--list` only discovers candidate channels; it
does not validate history access. Exit code 1 indicates a fatal error, empty
discovery, or failed channel/attachment operations. Discovery errors are reported
separately and should always be reviewed, even when the backup exits 0.

## Development and validation

```powershell
py -3 -m unittest discover -s tests -v
```

Tests use simulated Discord responses and temporary local databases. They cover
checkpoint recovery, incremental backups, per-channel failure isolation, exports,
token/header handling and attachment URL restrictions. Live account access and
Windows GUI execution require validation on Windows with your own credentials.

See `TEST_RESULTS.md` for actual checks performed and explicit unverified items.
