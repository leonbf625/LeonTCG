@echo off
setlocal
cd /d "%~dp0"
py -3 backup.py %*
set "backup_exit=%errorlevel%"
echo.
echo Backup exit code: %backup_exit%
pause
exit /b %backup_exit%
