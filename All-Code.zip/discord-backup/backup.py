"""Read-only Discord channel archiver. Requires Python 3.11+; no third-party packages."""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import getpass
import json
import os
from pathlib import Path
import queue
import re
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

API = "https://discord.com/api/v10"
MESSAGE_TYPES = {0, 2, 5, 10, 11, 12, 13}
THREAD_PARENTS = {0, 5, 15, 16}


class Stopped(Exception):
    pass


class APIError(Exception):
    def __init__(self, status, operation):
        self.status = status
        super().__init__(f"HTTP {status} during {operation}")


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class NoAPIRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Never forward an account token to a redirect destination.
        return None


class DiscordAPI:
    def __init__(self, token, bot=False, stop=None, opener=None):
        self._authorization = ("Bot " if bot else "") + token.strip()
        self.stop = stop or threading.Event()
        self.opener = opener or urllib.request.build_opener(NoAPIRedirect()).open

    def pause(self, seconds):
        if self.stop.wait(seconds):
            raise Stopped()

    def get(self, path, **params):
        if not path.startswith("/") or "://" in path:
            raise ValueError("Expected a relative Discord API path")
        url = API + path
        if params:
            url += "?" + urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})
        for attempt in range(8):
            if self.stop.is_set():
                raise Stopped()
            request = urllib.request.Request(url, headers={
                "Authorization": self._authorization,
                "User-Agent": "DiscordBackup/1.0 (local read-only archive)",
                "Accept": "application/json",
            })
            try:
                with self.opener(request, timeout=45) as response:
                    result = json.load(response)
                    remaining = response.headers.get("X-RateLimit-Remaining")
                    reset = response.headers.get("X-RateLimit-Reset-After", "1")
                if remaining == "0":
                    self.pause(min(max(float(reset), 0), 120))
                return result
            except urllib.error.HTTPError as exc:
                if exc.code == 429:
                    try:
                        delay = float(json.loads(exc.read()).get("retry_after", 1))
                    except (ValueError, TypeError):
                        delay = 2
                    if delay > 120:
                        raise APIError(429, "request; rate limit exceeds two minutes") from None
                    self.pause(max(1, delay))
                elif exc.code >= 500:
                    self.pause(min(2 ** attempt, 30))
                else:
                    raise APIError(exc.code, "Discord request") from None
            except (urllib.error.URLError, TimeoutError, ConnectionError, OSError):
                self.pause(min(2 ** attempt, 30))
        raise APIError(503, "Discord request; retry limit reached")


class Archive:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.folder / "archive.sqlite3")
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS channels (
                id TEXT PRIMARY KEY, name TEXT NOT NULL, guild_id TEXT, guild_name TEXT,
                kind INTEGER, status TEXT NOT NULL DEFAULT 'not started', error TEXT);
            CREATE TABLE IF NOT EXISTS messages (
                channel_id TEXT NOT NULL, id TEXT NOT NULL, author TEXT NOT NULL,
                timestamp TEXT, content TEXT NOT NULL, raw_json TEXT NOT NULL,
                PRIMARY KEY(channel_id,id));
            CREATE TABLE IF NOT EXISTS progress (
                channel_id TEXT PRIMARY KEY, high_water TEXT NOT NULL DEFAULT '0',
                running INTEGER NOT NULL DEFAULT 0, cursor TEXT, target TEXT);
            CREATE TABLE IF NOT EXISTS attachments (
                id TEXT PRIMARY KEY, channel_id TEXT NOT NULL, message_id TEXT NOT NULL,
                filename TEXT NOT NULL, url TEXT NOT NULL, saved_path TEXT, error TEXT);
            CREATE TABLE IF NOT EXISTS events (
                time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, scope TEXT, detail TEXT);
            CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS messages_recent ON messages(length(id) DESC,id DESC);
            CREATE INDEX IF NOT EXISTS attachments_channel ON attachments(channel_id);
        ''')
        existing = {row[1] for row in self.db.execute("PRAGMA table_info(channels)")}
        for column in ("last_started_at", "last_checked_at", "last_success_at"):
            if column not in existing:
                self.db.execute(f"ALTER TABLE channels ADD COLUMN {column} TEXT")
        self.db.commit()

    def close(self):
        self.db.close()

    def event(self, scope, detail):
        with self.db:
            self.db.execute("INSERT INTO events(scope,detail) VALUES (?,?)", (scope, detail))

    def bind_account(self, account):
        identifier = str(account["id"])
        previous = self.db.execute("SELECT value FROM metadata WHERE key='account'").fetchone()
        if previous and json.loads(previous[0])["id"] != identifier:
            raise ValueError("This backup folder belongs to a different Discord account. Choose a separate folder.")
        safe = {key: account.get(key) for key in ("id", "username", "global_name", "bot")}
        safe["id"] = identifier
        with self.db:
            self.db.execute("INSERT INTO metadata VALUES ('account',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (json.dumps(safe),))

    def channel(self, item):
        with self.db:
            self.db.execute('''INSERT INTO channels(id,name,guild_id,guild_name,kind)
                VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,
                guild_id=excluded.guild_id,guild_name=excluded.guild_name,kind=excluded.kind''',
                (item["id"], item["name"], item.get("guild_id"), item.get("guild_name"), item.get("type", 0)))

    def status(self, channel_id, status, error=None):
        with self.db:
            self.db.execute("UPDATE channels SET status=?,error=? WHERE id=?", (status, error, channel_id))
            column = "last_started_at" if status == "backing up" else "last_checked_at"
            self.db.execute(f"UPDATE channels SET {column}=? WHERE id=?", (utc_now(), channel_id))

    def state(self, channel_id):
        with self.db:
            self.db.execute("INSERT OR IGNORE INTO progress(channel_id) VALUES (?)", (channel_id,))
        return self.db.execute("SELECT high_water,running,cursor,target FROM progress WHERE channel_id=?", (channel_id,)).fetchone()

    def page(self, channel_id, messages, cursor, target):
        # Message rows and their resume cursor must commit together.
        with self.db:
            for message in messages:
                self.db.execute('''INSERT INTO messages VALUES (?,?,?,?,?,?)
                    ON CONFLICT(channel_id,id) DO UPDATE SET author=excluded.author,
                    timestamp=excluded.timestamp,content=excluded.content,raw_json=excluded.raw_json''',
                    (channel_id, message["id"], message.get("author", {}).get("username", "unknown"),
                     message.get("timestamp"), message.get("content", ""), json.dumps(message, ensure_ascii=False)))
                for attachment in message.get("attachments", []):
                    self.db.execute('''INSERT INTO attachments(id,channel_id,message_id,filename,url)
                        VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET url=excluded.url''',
                        (attachment["id"], channel_id, message["id"], attachment.get("filename", "file"), attachment["url"]))
            self.db.execute("UPDATE progress SET running=1,cursor=?,target=? WHERE channel_id=?", (cursor, target, channel_id))

    def finish(self, channel_id, high_water):
        with self.db:
            self.db.execute("UPDATE progress SET high_water=?,running=0,cursor=NULL,target=NULL WHERE channel_id=?", (high_water, channel_id))
            self.db.execute("UPDATE channels SET status='history backed up',error=NULL WHERE id=?", (channel_id,))
            now = utc_now()
            self.db.execute("UPDATE channels SET last_checked_at=?,last_success_at=? WHERE id=?", (now, now, channel_id))

    def report(self):
        columns = ["id", "guild_id", "guild", "channel", "status", "error", "last_started_at", "last_checked_at", "last_success_at", "messages", "attachments", "downloaded", "attachment_errors"]
        rows = self.db.execute('''SELECT c.id,c.guild_id,c.guild_name,c.name,c.status,c.error,c.last_started_at,c.last_checked_at,c.last_success_at,
            (SELECT COUNT(*) FROM messages m WHERE m.channel_id=c.id),
            (SELECT COUNT(*) FROM attachments a WHERE a.channel_id=c.id),
            (SELECT COUNT(*) FROM attachments a WHERE a.channel_id=c.id AND saved_path IS NOT NULL),
            (SELECT COUNT(*) FROM attachments a WHERE a.channel_id=c.id AND error IS NOT NULL)
            FROM channels c ORDER BY c.guild_name,c.name''').fetchall()
        account = self.db.execute("SELECT value FROM metadata WHERE key='account'").fetchone()
        data = {"created_at": utc_now(), "account": json.loads(account[0]) if account else None,
                "channels": [dict(zip(columns, row)) for row in rows],
                "events": [dict(zip(["time", "scope", "detail"], row)) for row in self.db.execute("SELECT time,scope,detail FROM events ORDER BY rowid DESC LIMIT 200")]}
        for row in data["channels"]:
            row["checked"] = row["last_checked_at"] is not None
            row["history_complete"] = row["status"] == "history backed up"
        data["coverage"] = {
            "discovered": len(rows),
            "checked": sum(row["checked"] for row in data["channels"]),
            "unchecked": sum(not row["checked"] for row in data["channels"]),
            "history_complete": sum(row["history_complete"] for row in data["channels"]),
            "failed": sum(row["status"] == "failed" for row in data["channels"]),
        }
        temporary = self.folder / "report.json.tmp"
        temporary.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        temporary.replace(self.folder / "report.json")
        csv_path = self.folder / "coverage.csv"
        csv_temporary = csv_path.with_suffix(".csv.tmp")
        with csv_temporary.open("w", encoding="utf-8-sig", newline="") as output:
            writer = csv.writer(output)
            writer.writerow(columns)
            for row in rows:
                writer.writerow([("'" + value if value.startswith(("=", "+", "-", "@")) else value) if isinstance(value, str) else value for value in row])
        csv_temporary.replace(csv_path)
        return data

    def export(self, channel_id):
        # Stream the entire archive without loading a large channel into memory.
        destination = self.folder / "exports"
        destination.mkdir(exist_ok=True)
        path = destination / f"{channel_id}.jsonl"
        temporary = path.with_suffix(".jsonl.tmp")
        with temporary.open("w", encoding="utf-8") as output:
            for (raw,) in self.db.execute("SELECT raw_json FROM messages WHERE channel_id=? ORDER BY length(id),id", (channel_id,)):
                output.write(raw + "\n")
        temporary.replace(path)


def discover(api, archive, notify=lambda message: None):
    """Discover guild channels plus active and accessible archived threads."""
    found = {}
    guilds = []
    after = None
    while True:
        page = api.get("/users/@me/guilds", limit=200, after=after)
        guilds.extend(page)
        if len(page) < 200:
            break
        after = page[-1]["id"]
    for guild in guilds:
        notify(f"Discovering {guild['name']}")
        def remember(items):
            for item in items:
                if item["type"] in MESSAGE_TYPES:
                    item = dict(item, guild_id=guild["id"], guild_name=guild["name"])
                    found[item["id"]] = item
                    archive.channel(item)
        def optional(path, key=None, **params):
            try:
                result = api.get(path, **params)
                return result if key is None else result.get(key, [])
            except APIError as exc:
                archive.event(path, str(exc))
                notify(f"Discovery incomplete: {path}: {exc}")
                return None
        channels = optional(f"/guilds/{guild['id']}/channels")
        if channels is None:
            continue
        remember(channels)
        remember(optional(f"/guilds/{guild['id']}/threads/active", "threads") or [])
        for parent in channels:
            if parent["type"] not in THREAD_PARENTS:
                continue
            # No joining channels/threads or permission changes are performed.
            for suffix in ("public", "private"):
                before = None
                while True:
                    result = optional(f"/channels/{parent['id']}/threads/archived/{suffix}", limit=100, before=before)
                    if result is None:
                        break
                    threads = result.get("threads", [])
                    remember(threads)
                    if not result.get("has_more") or not threads:
                        break
                    next_before = threads[-1].get("thread_metadata", {}).get("archive_timestamp")
                    if not next_before or next_before == before:
                        archive.event(parent["id"], "Archived thread pagination did not advance; discovery incomplete")
                        break
                    before = next_before
    archive.report()
    return list(found.values())


def backup_channel(api, archive, channel_id, notify=lambda message: None):
    high, running, cursor, target = archive.state(channel_id)
    if not running:
        cursor, target = None, None
    archive.status(channel_id, "backing up")
    try:
        while True:
            messages = api.get(f"/channels/{channel_id}/messages", limit=100, before=cursor)
            if not messages:
                archive.finish(channel_id, target or high)
                break
            if not isinstance(messages, list) or any(not str(m.get("id", "")).isdigit() for m in messages):
                raise ValueError("Unexpected message response")
            if target is None:
                target = str(max(int(high), max(int(m["id"]) for m in messages)))
            next_cursor = str(min(int(m["id"]) for m in messages))
            if cursor and int(next_cursor) >= int(cursor):
                raise ValueError("Pagination did not advance; cursor preserved")
            fresh = [m for m in messages if int(m["id"]) > int(high)]
            archive.page(channel_id, fresh, next_cursor, target)
            notify(f"Channel {channel_id}: saved {len(fresh)} messages")
            cursor = next_cursor
            if len(messages) < 100 or any(int(m["id"]) <= int(high) for m in messages):
                archive.finish(channel_id, target)
                break
    except Stopped:
        archive.status(channel_id, "paused")
        raise
    except Exception as exc:
        archive.status(channel_id, "failed", str(exc))
        archive.event(channel_id, str(exc))
        raise
    finally:
        archive.report()


def attachment_url(url):
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != "https" or parsed.hostname not in {"cdn.discordapp.com", "media.discordapp.net"} or parsed.port not in (None, 443) or parsed.username:
        raise ValueError("Attachment URL is not an approved Discord HTTPS host")
    return url


class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        attachment_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def download_attachments(archive, stop, notify=lambda message: None):
    # A separate opener deliberately never receives the account Authorization header.
    opener = urllib.request.build_opener(SafeRedirect())
    failures = 0
    for aid, channel_id, filename, url in archive.db.execute(
            "SELECT id,channel_id,filename,url FROM attachments WHERE saved_path IS NULL").fetchall():
        if stop.is_set():
            raise Stopped()
        temporary = None
        try:
            attachment_url(url)
            safe = re.sub(r"[^A-Za-z0-9._-]", "_", filename)[:100] or "file"
            if not aid.isdigit() or not channel_id.isdigit():
                raise ValueError("Invalid attachment identifier")
            relative = Path("attachments") / channel_id / f"{aid}_{safe}"
            path = archive.folder / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            temporary = path.with_name(path.name + ".part")
            for attempt in range(4):
                try:
                    with opener.open(url, timeout=60) as response, temporary.open("wb") as output:
                        count = 0
                        expected = response.headers.get("Content-Length")
                        while block := response.read(256 * 1024):
                            if stop.is_set():
                                raise Stopped()
                            output.write(block)
                            count += len(block)
                        if expected is not None and count != int(expected):
                            raise OSError("Incomplete attachment response")
                    break
                except (urllib.error.URLError, TimeoutError, ConnectionError, OSError):
                    if attempt == 3:
                        raise RuntimeError("Attachment download failed after four attempts; URL may have expired") from None
                    if stop.wait(min(2 ** attempt, 8)):
                        raise Stopped()
            temporary.replace(path)
            with archive.db:
                archive.db.execute("UPDATE attachments SET saved_path=?,error=NULL WHERE id=?", (relative.as_posix(), aid))
        except Stopped:
            raise
        except Exception as exc:
            failures += 1
            # Do not persist signed URLs in error messages.
            detail = str(exc) if isinstance(exc, (ValueError, RuntimeError)) else type(exc).__name__
            with archive.db:
                archive.db.execute("UPDATE attachments SET error=? WHERE id=?", (detail, aid))
            notify(f"Attachment {aid} failed: {detail}")
        finally:
            if temporary and temporary.exists():
                temporary.unlink()
    archive.report()
    return failures


def run_backup(api, archive, channels, media=True, notify=print):
    failures = 0
    for channel in channels:
        if not str(channel["id"]).isdigit():
            raise ValueError("Channel IDs must contain only digits")
        archive.channel(channel)
        try:
            backup_channel(api, archive, channel["id"], notify)
            archive.export(channel["id"])
        except Stopped:
            raise
        except Exception as exc:
            failures += 1
            notify(f"Channel {channel['id']} failed: {exc}; continuing")
    if media:
        failures += download_attachments(archive, api.stop, notify)
    archive.report()
    return failures


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="DiscordBackup")
    parser.add_argument("--bot", action="store_true", help="Use an authorized bot token")
    parser.add_argument("--channels", nargs="+", help="Specific channel IDs; otherwise discover server channels")
    parser.add_argument("--no-attachments", action="store_true")
    parser.add_argument("--list", action="store_true", help="Discover channels without downloading messages")
    args = parser.parse_args()
    token = os.environ.get("DISCORD_BACKUP_TOKEN") or getpass.getpass("Discord token (hidden, never saved): ")
    if not token.strip():
        parser.error("A token is required")
    api = DiscordAPI(token, bot=args.bot)
    archive = Archive(args.output)
    try:
        account = api.get("/users/@me")
        archive.bind_account(account)
        print(f"Connected account: {account.get('username', 'unknown')} (ID {account['id']})")
        if args.channels:
            channels = [{"id": cid, "name": cid} for cid in args.channels]
        else:
            channels = discover(api, archive, print)
        if args.list:
            for channel in channels:
                print(f"{channel['id']}  {channel.get('guild_name', '')} / {channel['name']}")
            return 0
        if not channels:
            print("No channels discovered. Check report.json; no backup was performed.")
            return 1
        failures = run_backup(api, archive, channels, not args.no_attachments)
        print(f"Backup finished with {failures} failed channel/attachment operations. See report.json.")
        return 1 if failures else 0
    except KeyboardInterrupt:
        api.stop.set()
        print("Stopped. Committed message pages will resume next time.")
        return 130
    except Exception as exc:
        print(f"Backup stopped: {exc}")
        return 1
    finally:
        archive.report()
        archive.close()


if __name__ == "__main__":
    raise SystemExit(main())
