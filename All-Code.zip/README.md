# Discord backup — combined code and Windows test build

All source, tests and documentation are in discord-backup/ and pokemon-tracker/.
The latter is the earlier card-bot prototype, superseded by the backup application.
MANIFEST.json verifies source-file hashes. Credentials, real Discord messages,
backup databases, installed dependencies and compiler caches are excluded.
Personal service/account defaults have been replaced with public placeholders.

For the Windows test bundle, Extract All and run Windows/DiscordLocalBackup-Windows-x64.exe.
It is an unsigned Windows 10/11 x64 test build with a bundled official Python runtime.
It has not been executed on Windows in this environment. Use Windows/Upload Exports.cmd
to upload existing DiscordChatExporter JSON; use --watch from PowerShell to watch a folder.

Cloudflare-Receiver.js is a complete single-file Worker with the private website
embedded. It can replace the supplied POST-only receiver while reusing EXPORTS.
Configure DASHBOARD_EMAIL, DASHBOARD_PASSWORD and UPLOAD_TOKEN securely in Cloudflare.
Read discord-backup/website/EXISTING_WORKER.md before deploying. No live deployment
or authenticated Discord test has been performed. The uploader performs a readiness
check and checksum confirmation; it never needs a Discord token.

See discord-backup/TEST_RESULTS.md for exact validation evidence and limitations.
To rebuild the EXE, prepare the verified upstream runtime ZIP identified by
runtime-provenance.json and use build_windows.py with an official Go compiler.
The source-only ZIP does not include the EXE or upstream runtime binaries.
