# All code from this conversation

- `discord-backup/`: Windows/local-browser Discord backup app, SQLite archive,
  automatic scanner, optional private Cloudflare dashboard, DeepSeek prompt export,
  tests, Windows launchers, Go EXE launcher source, build script and documentation.
- `pokemon-tracker/`: earlier collection/wishlist bot prototype, superseded by the
  backup application. It is included because this archive collects all code written.
- `MANIFEST.json`: file list, sizes and SHA-256 hashes.

No account credentials, real Discord messages, backup databases, installed npm/pip
packages, compiler caches or upstream runtime binaries are included. Cloudflare's
configured dashboard username is a non-secret setting; replace it if needed.

To run the current application from source, see discord-backup/README.md.
To rebuild the Windows EXE, build_windows.py requires an official checksum-verified
Go compiler and launcher/runtime.zip prepared from the official Python package
identified in runtime-provenance.json. Those upstream binaries are not source code
written in this conversation and are not included here. The separately uploaded
Windows test bundle contains the ready-built EXE.

See discord-backup/TEST_RESULTS.md for test evidence and unverified items. No live
Discord account was connected, and the Cloudflare website has not been deployed.

Public export: the owner email was replaced with you@example.com. Configure your own dashboard login name before deploying.
