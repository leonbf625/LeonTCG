# Discord Pokémon card tracker

A personal card collection and wishlist bot with persistent SQLite storage. Card
names are entered manually: include the set and collector number to distinguish
printings. This version does not fetch prices, stock, or Pokémon GO events.
Lists belong to Discord users and follow them across servers. Replies are private.

## Install and test

Requires Python 3.12 or later. From `/workspace/pokemon-tracker`:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m unittest -v
```

## Connect to Discord

1. Open https://discord.com/developers/applications and create a new application
   named Pokémon Tracker.
2. Open **Bot** and obtain its bot token. Store it as `DISCORD_TOKEN` in your
   runtime's secure environment settings. Never paste it into chat or commit it.
3. Under **Installation**, enable server installation and choose the `bot` and
   `applications.commands` scopes. No administrator or privileged gateway
   intents are required. Use the install link to add it to a server you manage.
4. Optionally set `DISCORD_GUILD_ID` to your test server's ID for immediate
   server-specific slash command registration. Without it, global commands may
   take time to appear. Enable Developer Mode in Discord to copy server IDs.
5. With the variables supplied securely, run:

```sh
cd /workspace/pokemon-tracker
.venv/bin/python bot.py
```

Use `/card_add`, `/cards`, `/card_remove`, and `/cards_export`. Choose Collection
or Wishlist in each command. Adding the same card again increments its quantity;
removing deletes the complete entry. To verify the live integration, add a test
card, list it, export it, remove it, and confirm it is gone.

`TRACKER_DB` optionally overrides `data/cards.sqlite3`. Keep the database on a
persistent disk and back it up while the bot is stopped. Restart the process after
machine restarts. Running the same bot token in multiple processes is unsupported.

No Discord application, server installation, or live integration is created by
installing these files. The bot requires outbound HTTPS and WebSocket access to
Discord (including discord.com and gateway.discord.gg); this cloud environment's
network policy and proxy compatibility must be validated before live operation.
