import sqlite3
from contextlib import closing


class Store:
    def __init__(self, path):
        self.path = path
        with closing(sqlite3.connect(path)) as db, db:
            db.execute('''CREATE TABLE IF NOT EXISTS cards (
                user_id TEXT NOT NULL, card TEXT NOT NULL, list_name TEXT NOT NULL,
                quantity INTEGER NOT NULL CHECK(quantity > 0),
                PRIMARY KEY(user_id, card, list_name))''')

    def add(self, user_id, card, list_name, quantity):
        card = ' '.join(card.split()).casefold()
        if not card or len(card) > 100:
            raise ValueError('Use a card name between 1 and 100 characters.')
        if list_name not in ('collection', 'wishlist'):
            raise ValueError('Choose collection or wishlist.')
        if not 1 <= quantity <= 999:
            raise ValueError('Quantity must be between 1 and 999.')
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute('''INSERT INTO cards VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id, card, list_name)
                DO UPDATE SET quantity = quantity + excluded.quantity''',
                (str(user_id), card, list_name, quantity))

    def remove(self, user_id, card, list_name):
        with closing(sqlite3.connect(self.path)) as db, db:
            result = db.execute('DELETE FROM cards WHERE user_id=? AND card=? AND list_name=?',
                                (str(user_id), ' '.join(card.split()).casefold(), list_name))
            return result.rowcount > 0

    def cards(self, user_id, list_name):
        with closing(sqlite3.connect(self.path)) as db:
            return db.execute('SELECT card, quantity FROM cards WHERE user_id=? AND list_name=? ORDER BY card',
                              (str(user_id), list_name)).fetchall()
