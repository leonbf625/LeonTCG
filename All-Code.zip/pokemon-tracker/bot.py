import io
import csv
import os
from pathlib import Path

import discord
from discord import app_commands

from store import Store

ListName = app_commands.Choice[str]
LISTS = [ListName(name='Collection', value='collection'), ListName(name='Wishlist', value='wishlist')]


class Tracker(discord.Client):
    def __init__(self):
        super().__init__(intents=discord.Intents.none(), allowed_mentions=discord.AllowedMentions.none())
        self.tree = app_commands.CommandTree(self)
        path = Path(os.environ.get('TRACKER_DB', 'data/cards.sqlite3'))
        path.parent.mkdir(parents=True, exist_ok=True)
        self.store = Store(str(path))

    async def setup_hook(self):
        guild_id = os.environ.get('DISCORD_GUILD_ID')
        if guild_id:
            guild = discord.Object(id=int(guild_id))
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
        else:
            await self.tree.sync()

    async def on_ready(self):
        print(f'Pokémon tracker connected as {self.user}', flush=True)


client = Tracker()


@client.tree.command(name='card_add', description='Add a Pokémon card to your collection or wishlist')
@app_commands.choices(list_name=LISTS)
async def card_add(interaction: discord.Interaction, card: str, list_name: ListName, quantity: app_commands.Range[int, 1, 999] = 1):
    try:
        client.store.add(interaction.user.id, card, list_name.value, quantity)
    except ValueError as exc:
        await interaction.response.send_message(str(exc), ephemeral=True)
        return
    await interaction.response.send_message(f'Added {quantity} card(s) to your {list_name.value}.', ephemeral=True)


@client.tree.command(name='card_remove', description='Remove a card entry and all its copies from your list')
@app_commands.choices(list_name=LISTS)
async def card_remove(interaction: discord.Interaction, card: str, list_name: ListName):
    removed = client.store.remove(interaction.user.id, card, list_name.value)
    await interaction.response.send_message('Entry removed.' if removed else 'Card not found.', ephemeral=True)


@client.tree.command(name='cards', description='View your collection or wishlist')
@app_commands.choices(list_name=LISTS)
async def cards(interaction: discord.Interaction, list_name: ListName):
    rows = client.store.cards(interaction.user.id, list_name.value)
    lines = [f'{quantity} × {discord.utils.escape_markdown(card)}' for card, quantity in rows]
    body = '\n'.join(lines)
    if len(body) > 1800:
        body = '\n'.join(lines[:10]) + '\n… Use /cards_export for your full list.'
    await interaction.response.send_message(body or 'Your list is empty. Use /card_add to begin.', ephemeral=True)


@client.tree.command(name='cards_export', description='Download your complete list as CSV')
@app_commands.choices(list_name=LISTS)
async def cards_export(interaction: discord.Interaction, list_name: ListName):
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(['card', 'quantity'])
    for card, quantity in client.store.cards(interaction.user.id, list_name.value):
        # Prevent spreadsheet programs from interpreting user-entered names as formulas.
        writer.writerow(["'" + card if card.startswith(('=', '+', '-', '@')) else card, quantity])
    attachment = discord.File(io.BytesIO(buffer.getvalue().encode()), filename=f'{list_name.value}.csv')
    await interaction.response.send_message(file=attachment, ephemeral=True)


if __name__ == '__main__':
    token = os.environ.get('DISCORD_TOKEN')
    if not token:
        raise SystemExit('Set DISCORD_TOKEN securely in your environment before starting the bot.')
    client.run(token)
