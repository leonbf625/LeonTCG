import tempfile
import unittest
from pathlib import Path

from store import Store


class StoreTests(unittest.TestCase):
    def test_persistence_normalization_and_isolation(self):
        with tempfile.TemporaryDirectory() as folder:
            path = str(Path(folder) / 'cards.sqlite3')
            store = Store(path)
            store.add(1, ' Pikachu   025 ', 'collection', 2)
            store.add(1, 'PIKACHU 025', 'collection', 1)
            store.add(2, 'Pikachu 025', 'wishlist', 4)
            self.assertEqual(Store(path).cards(1, 'collection'), [('pikachu 025', 3)])
            self.assertEqual(store.cards(1, 'wishlist'), [])
            self.assertFalse(store.remove(1, 'Pikachu 025', 'wishlist'))
            self.assertTrue(store.remove(1, 'Pikachu 025', 'collection'))
            self.assertEqual(store.cards(2, 'wishlist'), [('pikachu 025', 4)])

    def test_invalid_entries(self):
        with tempfile.TemporaryDirectory() as folder:
            store = Store(str(Path(folder) / 'cards.sqlite3'))
            for card, list_name, quantity in [('', 'collection', 1), ('Pika', 'unknown', 1), ('Pika', 'wishlist', 0)]:
                with self.assertRaises(ValueError):
                    store.add(1, card, list_name, quantity)


if __name__ == '__main__':
    unittest.main()
