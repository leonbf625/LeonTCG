# Discord backup — all code and Windows test build

Windows 10/11 x64: Extract All, then run Windows/DiscordLocalBackup-Windows-x64.exe.
No Python installation is required for the EXE. Keep its console open while scanning.
The EXE is unsigned and has not been executed on Windows in this environment.
Enter Discord authentication locally; the tool cannot inherit this chat's login.

Source folders:
- discord-backup/: current backup app, Cloudflare dashboard, tests and build scripts.
- pokemon-tracker/: earlier card collection/wishlist bot prototype.

The app identifies the account and channels, tracks checked/unchecked/failed
channels with last-check times, resumes backups, scans automatically, optionally
syncs a private Cloudflare website, and exports local Markdown prompts for DeepSeek.
Cloudflare deployment still requires your account login; no website is deployed.

No Discord credentials, real messages or backup databases are included. The owner's
account email was replaced by you@example.com in this public distribution. Set
your own dashboard username before deployment. Installed npm/pip dependencies and
compiler caches are omitted; the EXE bundles an official verified Python runtime.

See discord-backup/TEST_RESULTS.md for test evidence and unverified items.
MANIFEST.json lists source-file hashes. Windows/SHA256SUMS.txt checks the EXE.
